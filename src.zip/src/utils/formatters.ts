

export const formatCurrency = (amount: number | string | undefined | null, currency: 'RIAL' | 'USD' | undefined): string => {
    const numAmount = (typeof amount === 'string' && amount.trim() !== '') ? parseFloat(amount) : amount;
    if (typeof numAmount !== 'number' || isNaN(numAmount)) return '---';

    const formattedAmount = new Intl.NumberFormat('fa-IR').format(numAmount);
    if (currency === 'RIAL') return `${formattedAmount} ریال`;
    if (currency === 'USD') return `${formattedAmount} $`;
    return formattedAmount;
};

export const formatNumber = (amount: number | string | undefined | null): string => {
    const numAmount = (typeof amount === 'string' && amount.trim() !== '') ? parseFloat(amount) : amount;
    if (typeof numAmount !== 'number' || isNaN(numAmount)) return '---';
    return new Intl.NumberFormat('fa-IR').format(numAmount);
};

/**
 * Transliterates a Persian full name into a standardized, system-ready username and email.
 * This function converts Persian characters to their English phonetic equivalents,
 * replaces spaces with dots, and formats the result for use in system fields.
 * @param fullName The full name in Persian.
 * @returns An object containing the generated username and corresponding email address.
 */
export const generateUsernameAndEmail = (fullName: string): { username: string; email: string } => {
  if (!fullName) {
    return { username: '', email: '' };
  }

  const persianToEnglishMap: { [key: string]: string } = {
    'ا': 'a', 'آ': 'a', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ث': 's', 'ج': 'j', 'چ': 'ch',
    'ح': 'h', 'خ': 'kh', 'د': 'd', 'ذ': 'z', 'ر': 'r', 'ز': 'z', 'ژ': 'zh', 'س': 's',
    'ش': 'sh', 'ص': 's', 'ض': 'z', 'ط': 't', 'ظ': 'z', 'ع': 'a', 'غ': 'gh', 'ف': 'f',
    'ق': 'q', 'ک': 'k', 'گ': 'g', 'ل': 'l', 'م': 'm', 'ن': 'n', 'و': 'v', 'ه': 'h',
    'ی': 'y', ' ': '.',
  };

  const username = fullName
    .split('')
    .map(char => persianToEnglishMap[char] || char)
    .join('')
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, '');

  const email = `${username}@system.local`;

  return { username, email };
};