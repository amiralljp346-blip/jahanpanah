
import { useContext } from 'react';
// FIX: Replaced '@' alias with a relative path to resolve module error.
// FIX: Imported ToastContextType to ensure correct type inference for the context.
import { ToastContext, type ToastContextType } from '../context/ToastContext';

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return {
    success: (message: string) => context.addToast(message, 'success'),
    error: (message: string) => context.addToast(message, 'error'),
    info: (message: string) => context.addToast(message, 'info'),
  };
};
