
import { useContext } from 'react';
// FIX: Replaced '@' alias with a relative path to resolve module error.
import { AuthContext } from '../context/AuthContext';

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
