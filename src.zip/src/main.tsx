
import React from 'react';
import ReactDOM from 'react-dom/client';
// FIX: Replaced named import from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { BrowserRouter } = ReactRouterDOM;
import { QueryClientProvider } from '@tanstack/react-query';
import { QueryClient } from '@tanstack/query-core';
// FIX: Replaced '@' alias with relative path to resolve module resolution error.
import App from './App';
// FIX: Replaced '@' alias with relative path to resolve module resolution error.
import { AuthProvider } from './context/AuthContext';
// FIX: Replaced '@' alias with relative path to resolve module resolution error.
import { ToastProvider } from './context/ToastContext';
// FIX: Replaced '@' alias with relative path to resolve module resolution error.
import InitializationCheck from './components/InitializationCheck';
// FIX: Replaced '@' alias with relative path to resolve module resolution error.
import './index.css';

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <InitializationCheck>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <AuthProvider>
            <ToastProvider>
              <App />
            </ToastProvider>
          </AuthProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </InitializationCheck>
  </React.StrictMode>,
);
