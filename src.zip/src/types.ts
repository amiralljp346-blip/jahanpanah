import { z } from 'zod';

// Base Interfaces
export interface Role {
  id: number;
  name: string;
  description?: string;
  permissions: string[];
  status: 'ACTIVE' | 'INACTIVE';
}

export interface Person {
  id: number;
  fullName: string;
  firstName: string;
  lastName: string;
  personnelCode?: string;
  fax?: string;
  photoUrl?: string;
  signatures?: Attachment[];
  username?: string;
  password?: string;
  nationalId?: string;
  isSystemUser: boolean;
  isBeneficiary: boolean;
  accountNumber?: string;
  cardNumber?: string;
  iban?: string;
  address?: string;
  phone?: string;
  roleIds: number[];
  permissions?: string[];
  unitId?: number; // From direct assignment
  unitName?: string; // Joined from backend via Position
  roleNames?: string[]; // Joined from backend
  position?: string; // Joined from backend via Position
  pettyCashLimit?: number;
  pettyCashBalance?: number;
  personType?: 'NATURAL' | 'LEGAL';
  // New fields for security management from user's screenshot
  status?: 'ACTIVE' | 'INACTIVE';
  forcePasswordChange?: boolean;
  passwordNoExpiration?: boolean;
}

export interface Unit {
  id: number;
  name: string;
  code: string;
  parentId?: number | null;
  credit?: number;
}

export interface Position {
  id: number;
  title: string;
  unitId: number;
  personId?: number | null;
  // Joined fields
  unitName?: string;
  personName?: string;
}

export interface RequestCategory {
  id: number;
  key: string;
  label: string;
  attachments: string[];
  subtypes?: { id: number; label: string }[];
  deadlineDays?: number;
}

export interface AssigneeRule {
  type: 'USER' | 'UNIT_MANAGER' | 'ROLE' | 'UNIT_AND_ROLE' | 'POSITION';
  userId?: number;
  roleId?: number;
  unitId?: number;
  positionId?: number;
}

export interface WorkflowStep {
  id: number;
  name: string;
  assigneeRule: AssigneeRule;
}

export interface Workflow {
  id: number;
  name: string;
  requestCategoryId: number;
  steps: WorkflowStep[];
}

export interface InternalWorkflowStep {
  id: number;
  name: string;
  assigneeId: number;
  // FIX: Add assigneeName which is joined by the backend to resolve type error
  assigneeName?: string;
}

export interface InternalWorkflow {
  id: number;
  name:string;
  unitId: number;
  steps: InternalWorkflowStep[];
}

export interface Attachment {
  name: string;
  url: string;
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface Invoice {
  id?: number;
  invoiceNumber: string;
  beneficiaryId: number;
  attachmentName: string;
  attachmentUrl?: string;
  items: InvoiceItem[];
  // Joined from backend
  beneficiaryName?: string;
  beneficiaryAccountNumber?: string;
  beneficiaryCardNumber?: string;
  beneficiaryIban?: string;
}

export interface PaymentTerm {
    id: string; // A unique ID for the term within the contract, e.g., a timestamp or UUID
    type: 'PREPAYMENT' | 'PROGRESS_PAYMENT' | 'RETENTION' | 'FINAL_PAYMENT';
    description: string;
    percentage: number;
    amount: number;
    status: 'PENDING' | 'REQUESTED' | 'PAID';
}

export interface Contract {
    id: number;
    contractNumber: string;
    contractTitle: string;
    partyId: number;
    contractAmount: number;

    paidAmount: number;
    contractDate?: string;
    startDate?: string;
    endDate?: string;
    status: 'DRAFT' | 'ACTIVE' | 'COMPLETED' | 'TERMINATED';
    paymentTerms: PaymentTerm[];
    partyName?: string; // Joined from backend
    unitIds?: number[];
}

export interface SupplyRequest {
  id: string;
  workflowId: number;
  _activeSteps: { stepId: number; assigneeId: number; startTimestamp: string; assigneeName?: string }[];
  _history: {
    stepId: number;
    personId: number;
    action: 'APPROVE' | 'REJECT' | 'RESUBMIT' | 'INTERNAL_REVIEW_START' | 'INTERNAL_REVIEW_END';
    comment?: string;
    startTimestamp: string;
    endTimestamp: string;
    personName?: string;
    internalReviewDetails?: {
      mainStepId: number;
      mainAssigneeId: number;
      internalWorkflowId: number;
      history: { stepId: number; personId: number; action: 'FORWARD' | 'RETURN_TO_MANAGER'; comment?: string; timestamp: string; personName?: string }[];
      initiatorComment?: string;
      finalAction?: 'RETURN_TO_MANAGER' | 'FORWARDED_COMPLETE';
      completionTimestamp?: string;
    };
  }[];
  requestTypeId: string | number;
  requesterId: number;
  requestingUnitId: number;
  amount: number;
  currency: 'RIAL' | 'USD';
  status: 'DRAFT' | 'IN_REVIEW' | 'APPROVED' | 'REJECTED';
  submissionDate: string;
  submissionDateForSort: string;
  dueDate?: string;
  itemDescription?: string;
  fundingSource: 'RESEARCH' | 'PRODUCTION';
  expenseType?: 'CONSUMABLE' | 'CAPITAL';
  imprestHolderId?: number;
  attachments: Record<string, Attachment>;
  invoices: Invoice[];
  contractId?: number;
  paymentTermDescription?: string;
  // Deprecated fields
  contractType?: 'NEW' | 'OLD';
  relatedContractId?: string;
  paymentType?: string;
  _internalReview?: {
    mainStepId: number;
    mainAssigneeId: number;
    internalWorkflowId: number;
    history: { stepId: number; personId: number; action: 'FORWARD' | 'RETURN_TO_MANAGER'; comment?: string; timestamp: string; personName?: string }[];
    activeInternalStepId: number;
    activeInternalAssigneeId: number;
    initiatorComment?: string;
  };
  workflow?: Workflow;
  internalWorkflow?: InternalWorkflow;
  // Joined fields from backend for performance
  requesterName?: string;
  requestCategoryLabel?: string;
  requestingUnitName?: string;
  imprestHolderName?: string;
  canReferInternally?: boolean;
  availableInternalWorkflows?: InternalWorkflow[];
}

export interface ExpenseReportItem {
    description: string;
    amount: number;
    attachmentUrl?: string;
    attachmentName?: string;
}

export interface ExpenseReport {
    id: number;
    pettyCashHolderId: number;
    totalAmount: number;
    submissionDate: string;
    status: 'IN_REVIEW' | 'APPROVED' | 'REJECTED';
    items: ExpenseReportItem[];
    rejectionReason?: string;
    finalApprovalDate?: string;
    pettyCashHolderName?: string;
}

export interface CreateDraftData {
  requestTypeId?: string | number;
  imprestHolderId?: string;
  beneficiaryId?: string;
}

export interface Project {
  id: number;
  name: string;
  manager: string;
  budget: number;
}

export interface DebitCard {
    id: number;
    holderName: string;
    cardNumber: string;
    limit: number;
}

export interface SecuritySetting {
  id: number;
  roleId: number;
  resource: string;
  permissions: {
    create: boolean;
    read: boolean;
    update: boolean;
    delete: boolean;
  };
}

export interface AppearanceImage {
  id: number;
  name: string;
  url: string;
}

export interface AppearanceSettings {
  mode: 'default' | 'static' | 'slideshow';
  staticImageId: number | null;
  images: AppearanceImage[];
}

export interface TipsSettings {
  tips: string[];
  avatar: string; // base64 data URL
}

export interface ReportSummary {
  totalRequests: number;
  totalApprovedAmount: number;
  requestsByStatus: {
    IN_REVIEW: number;
    APPROVED: number;
    REJECTED: number;
    DRAFT: number;
  };
  topRequestingUnits: {
    requestingUnitId: number;
    totalAmount: number;
  }[];
}

export interface DashboardSummary {
  myPendingTasks: number;
  myRecentSubmissions: number;
  totalPending: number;
  totalApprovedThisMonth: number;
}

export interface InvoiceExplorerItem {
  id: number; // From row_number()
  description: string;
  quantity: number;
  unitPrice: number;
  requestId: string;
  submissionDate: string;
  beneficiaryName: string;
  requestingUnitName: string;
  currency: 'RIAL' | 'USD';
}

export interface Notification {
  id: number;
  personId: number;
  message: string;
  link: string; // The request ID
  isRead: boolean;
  createdAt: string;
}

export interface AuditLogEntry {
  id: number;
  timestamp: string;
  personId: number;
  personName: string;
  action: string;
  resourceType: string;
  resourceId: string;
  details: any;
}

export interface SecuritySummary {
  totalUsers: number;
  adminUsers: number;
  forceChangeUsers: number;
  noExpiryUsers: number;
}


export interface PaginatedResponse<T> {
  data: T[];
  total: number;
}

// Data Transfer Objects (for creation/updates)
export type PersonData = Omit<Person, 'id' | 'permissions' | 'unitName' | 'roleNames' | 'position'>;
export type UnitData = Pick<Unit, 'name' | 'parentId' | 'credit' | 'code'>;
export type PositionData = Omit<Position, 'id' | 'unitName' | 'personName'>;
export type SupplyRequestData = Omit<SupplyRequest, 'id' | 'workflow' | 'requesterName' | 'requestCategoryLabel'>;
export type RoleData = Omit<Role, 'id'>;
export type WorkflowData = Omit<Workflow, 'id'>;
export type RequestCategoryData = Omit<RequestCategory, 'id'>;
export type ProjectData = Omit<Project, 'id'>;
export type DebitCardData = Omit<DebitCard, 'id'>;
export type InternalWorkflowData = Omit<InternalWorkflow, 'id'>;
export type SecuritySettingData = Omit<SecuritySetting, 'id'>;
export type ExpenseReportData = Omit<ExpenseReport, 'id' | 'finalApprovalDate' | 'pettyCashHolderName'>;
export type BeneficiaryData = Omit<Person, 'id' | 'permissions' | 'unitName' | 'roleNames' | 'isSystemUser' | 'roleIds' | 'position'> & { isBeneficiary: true };
export type ContractData = Omit<Contract, 'id' | 'partyName'>;

export type UnitNode = Unit & {
    children: UnitNode[];
    persons: Person[];
};

// Zod Schemas for validation
export const PETTY_CASH_ROLE_ID = 15;

const AttachmentSchema = z.object({ name: z.string(), url: z.string() });

// Expanded schema for the detailed person form, based on the user's screenshot.
export const PersonSchema = z.object({
    id: z.number().optional(),
    firstName: z.string().min(2, "نام الزامی است"),
    lastName: z.string().min(2, "نام خانوادگی الزامی است"),
    personnelCode: z.string().optional(),
    unitId: z.preprocess(val => val ? Number(val) : undefined, z.number().optional()),
    nationalId: z.string().length(10, "کد ملی باید ۱۰ رقم باشد").regex(/^\d+$/, "کد ملی فقط می‌تواند شامل اعداد باشد").optional().or(z.literal('')),
    accountNumber: z.string().nullable().optional(),
    cardNumber: z.string().nullable().optional(),
    iban: z.string().nullable().optional(),
    pettyCashLimit: z.preprocess(val => val === '' ? undefined : Number(val), z.number().optional()),
});


// New schema specifically for creating and editing beneficiaries.
export const BeneficiarySchema = z.object({
    id: z.number().optional(),
    firstName: z.string().min(2, "نام الزامی است"),
    lastName: z.string().min(2, "نام خانوادگی الزامی است"),
    personType: z.enum(['NATURAL', 'LEGAL'], { message: "انتخاب نوع شخص الزامی است" }),
    nationalId: z.string().min(1, "کد/شناسه ملی الزامی است"),
    accountNumber: z.string().min(1, "شماره حساب الزامی است"),
    iban: z.string()
        .min(26, "شماره شبا باید ۲۶ کاراکتر باشد (همراه با IR)")
        .max(26, "شماره شبا باید ۲۶ کاراکتر باشد (همراه با IR)")
        .regex(/^IR\d{24}$/, "فرمت شماره شبا نامعتبر است. مثال صحیح: IR012345678901234567890123"),
    email: z.string().email("ایمیل نامعتبر است").nullable().optional().or(z.literal('')),
    address: z.string().nullable().optional(),
    phone: z.string().nullable().optional(),
}).superRefine((data, ctx) => {
    if (data.personType === 'NATURAL' && !/^\d{10}$/.test(data.nationalId)) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: "کد ملی برای شخص حقیقی باید ۱۰ رقم باشد", path: ["nationalId"] });
    }
    if (data.personType === 'LEGAL' && !/^\d{11}$/.test(data.nationalId)) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: "شناسه ملی برای شخص حقوقی باید ۱۱ رقم باشد", path: ["nationalId"] });
    }
});

export const NewUserSchema = z.object({
    personId: z.number(),
    username: z.string().min(3, "شناسه کاربری حداقل باید ۳ کاراکتر باشد"),
    password: z.string().min(6, "گذرواژه باید حداقل ۶ کاراکتر باشد"),
    confirmPassword: z.string(),
    roleIds: z.preprocess(val => {
        if (!val) return [];
        const arr = Array.isArray(val) ? val : [val];
        return arr.map(v => parseInt(String(v), 10)).filter(v => !isNaN(v));
    }, z.array(z.number()).min(1, "حداقل یک نقش برای کاربر انتخاب کنید")),
    status: z.enum(['ACTIVE', 'INACTIVE']),
    forcePasswordChange: z.boolean(),
    passwordNoExpiration: z.boolean(),
    description: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
    message: "تکرار گذرواژه مطابقت ندارد",
    path: ["confirmPassword"],
});


// Simplified schema for editing a user's roles and petty cash info on the Security page.
export const createUserRolesEditSchema = () => z.object({
    roleIds: z.preprocess(val => {
        if (!val) return [];
        const arr = Array.isArray(val) ? val : [val];
        return arr.map(v => parseInt(String(v), 10)).filter(v => !isNaN(v));
    }, z.array(z.number()).min(1, "حداقل یک نقش برای کاربر سیستم انتخاب کنید")),
    accountNumber: z.string().optional(),
    iban: z.string().optional(),
    pettyCashLimit: z.preprocess(val => val === '' ? undefined : Number(val), z.number().optional()),
}).superRefine((data, ctx) => {
    const hasPettyCashRole = data.roleIds.includes(PETTY_CASH_ROLE_ID);
    if (hasPettyCashRole) {
        if (!data.accountNumber || data.accountNumber.trim() === '') ctx.addIssue({ code: z.ZodIssueCode.custom, message: "شماره حساب برای تنخواه بگیر الزامی است", path: ["accountNumber"] });
        if (!data.iban || data.iban.trim() === '') ctx.addIssue({ code: z.ZodIssueCode.custom, message: "شماره شبا برای تنخواه بگیر الزامی است", path: ["iban"] });
        if (!data.pettyCashLimit || data.pettyCashLimit <= 0) ctx.addIssue({ code: z.ZodIssueCode.custom, message: "سقف اعتبار تنخواه باید مثبت باشد", path: ["pettyCashLimit"] });
    }
});


// Schema for an admin to reset a user's password.
export const UserPasswordResetSchema = z.object({
    password: z.string().min(6, "رمز عبور جدید باید حداقل ۶ کاراکتر باشد"),
});


export const UnitSchema = z.object({
  name: z.string().min(2, "نام واحد الزامی است"),
  code: z.string().optional(),
  credit: z.number().min(0).optional(),
  parentId: z.string().nullable().optional(),
});

export const PositionSchema = z.object({
  title: z.string().min(2, "عنوان پست الزامی است"),
  unitId: z.preprocess(val => Number(val), z.number().min(1, "انتخاب واحد الزامی است")),
  personId: z.preprocess(val => val ? Number(val) : null, z.number().nullable().optional()),
});

export const ProjectSchema = z.object({
  name: z.string().min(2, "نام پروژه الزامی است"),
  manager: z.string().min(2, "نام مدیر الزامی است"),
  budget: z.number().min(0, "بودجه نمی‌تواند منفی باشد"),
});

export const DebitCardSchema = z.object({
    holderName: z.string().min(1, "نام دارنده الزامی است"),
    cardNumber: z.string().min(16, "شماره کارت باید ۱۶ رقم باشد").max(19, "شماره کارت نامعتبر است"),
    limit: z.number().min(0, "سقف اعتبار نمی‌تواند منفی باشد"),
});

export const RoleSchema = z.object({
  name: z.string().min(2, "عنوان نقش الزامی است"),
  description: z.string().optional(),
  status: z.enum(['ACTIVE', 'INACTIVE']),
});


const AssigneeRuleSchema = z.object({
    type: z.enum(['USER', 'UNIT_MANAGER', 'ROLE', 'UNIT_AND_ROLE', 'POSITION']),
    userId: z.string().optional(),
    roleId: z.string().optional(),
    unitId: z.string().optional(),
    positionId: z.string().optional(),
});

const WorkflowStepSchema = z.object({
    name: z.string().min(1, "نام گام الزامی است"),
    assigneeRule: AssigneeRuleSchema,
}).superRefine((data, ctx) => {
    const { type, userId, roleId, unitId, positionId } = data.assigneeRule;
    switch (type) {
        case 'USER':
            if (!userId || userId === '') ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['assigneeRule'], message: "انتخاب کاربر الزامی است" });
            break;
        case 'ROLE':
            if (!roleId || roleId === '') ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['assigneeRule'], message: "انتخاب نقش الزامی است" });
            break;
        case 'UNIT_AND_ROLE':
            if (!unitId || unitId === '') ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['assigneeRule', 'unitId'], message: "انتخاب واحد الزامی است" });
            if (!roleId || roleId === '') ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['assigneeRule', 'roleId'], message: "انتخاب نقش الزامی است" });
            break;
        case 'POSITION':
            if (!positionId || positionId === '') ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['assigneeRule'], message: "انتخاب پست الزامی است" });
            break;
    }
});

export const WorkflowSchema = z.object({
    name: z.string().min(1, "نام فرآیند الزامی است"),
    requestCategoryId: z.string().min(1, "انتخاب نوع درخواست الزامی است"),
    steps: z.array(WorkflowStepSchema).min(1, "حداقل یک گام برای فرآیند تعریف کنید"),
});


export const RequestCategorySchema = z.object({
    label: z.string().min(2, "عنوان الزامی است"),
    attachments: z.array(z.string()),
    subtypes: z.array(z.object({ id: z.number(), label: z.string() })).optional(),
    deadlineDays: z.number().int().min(0).optional(),
});


const InternalWorkflowStepSchema = z.object({
    name: z.string().min(1, "نام گام الزامی است"),
    assigneeId: z.string().min(1, "انتخاب مسئول الزامی است"),
});

export const InternalWorkflowSchema = z.object({
    name: z.string().min(1, "نام فرآیند الزامی است"),
    unitId: z.string().min(1, "انتخاب واحد الزامی است"),
    steps: z.array(InternalWorkflowStepSchema).min(1, "حداقل یک گام برای فرآیند تعریف کنید"),
});

export const SecuritySettingSchema = z.object({
  roleId: z.number().min(1, "انتخاب نقش الزامی است"),
  resource: z.string().min(1, "انتخاب منبع الزامی است"),
  permissions: z.object({
    create: z.boolean(),
    read: z.boolean(),
    update: z.boolean(),
    delete: z.boolean(),
  }),
});

export const ChangePasswordSchema = z.object({
    currentPassword: z.string().min(1, "گذرواژه فعلی الزامی است"),
    newPassword: z.string().min(6, "گذرواژه جدید باید حداقل ۶ کاراکتر باشد"),
    confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
    message: "تکرار گذرواژه جدید مطابقت ندارد",
    path: ["confirmPassword"],
});


export const ExpenseReportSchema = z.object({
    pettyCashHolderId: z.number(),
    totalAmount: z.number(),
    items: z.array(z.object({
        description: z.string().min(1, "شرح هزینه الزامی است"),
        amount: z.number().min(1, "مبلغ باید مثبت باشد"),
        attachmentUrl: z.string().optional(),
        attachmentName: z.string().optional(),
    })).min(1, "حداقل یک هزینه ثبت کنید"),
});

const PaymentTermSchema = z.object({
    id: z.string(),
    type: z.enum(['PREPAYMENT', 'PROGRESS_PAYMENT', 'RETENTION', 'FINAL_PAYMENT']),
    description: z.string().min(1, "توضیحات شرط پرداخت الزامی است"),
    percentage: z.number().min(0.01, "درصد باید مثبت باشد").max(100, "درصد نمی‌تواند بیشتر از ۱۰۰ باشد"),
    amount: z.number(),
    status: z.enum(['PENDING', 'REQUESTED', 'PAID']),
});

export const ContractSchema = z.object({
    contractNumber: z.string().min(1, "شماره قرارداد الزامی است"),
    contractTitle: z.string().min(1, "عنوان قرارداد الزامی است"),
    partyId: z.string().min(1, "انتخاب طرف قرارداد الزامی است"),
    contractAmount: z.number().min(1, "مبلغ کل قرارداد باید مثبت باشد"),
    contractDate: z.string().optional(),
    startDate: z.string().optional(),
    endDate: z.string().optional(),
    status: z.enum(['DRAFT', 'ACTIVE', 'COMPLETED', 'TERMINATED']),
    paymentTerms: z.array(PaymentTermSchema).min(1, "حداقل یک شرط پرداخت تعریف کنید"),
    unitIds: z.preprocess((val) => {
        if (!val) return [];
        const arr = Array.isArray(val) ? val : [val];
        return arr.map(v => parseInt(String(v), 10)).filter(v => !isNaN(v));
    }, z.array(z.number()).optional()),
}).superRefine((data, ctx) => {
    const totalPercentage = data.paymentTerms.reduce((sum, term) => sum + term.percentage, 0);
    if (Math.round(totalPercentage) !== 100) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: `مجموع درصد شروط پرداخت باید دقیقا ۱۰۰٪ باشد. (مجموع فعلی: ${totalPercentage.toFixed(2)}٪)`,
            path: ["paymentTerms"],
        });
    }
});