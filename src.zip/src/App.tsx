





import React, { useState, useMemo, lazy, Suspense, useEffect } from 'react';
// FIX: Replaced named imports from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { Routes, Route, Navigate } = ReactRouterDOM;
import { useQuery } from '@tanstack/react-query';

// FIX: Replaced '@' alias with relative paths to resolve module errors.
import Header from './components/Header';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import Sidebar from './components/Sidebar';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import PageLoader from './components/PageLoader';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import ProtectedRoute from './components/ProtectedRoute';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { useAuth } from './hooks/useAuth';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { diagnosticsApi, tipsApi } from './services/api';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { ServerStatusContext, ServerStatus, useServerStatus } from './context/ServerStatusContext';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { MainLayoutContext, MainLayoutContextType } from './context/MainLayoutContext';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import OfflineAiAssistant from './components/OfflineAiAssistant';
import FinancialTipModal from './components/FinancialTipModal';

// Lazy load page components for code splitting
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const WelcomePage = lazy(() => import('./components/WelcomePage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const DashboardPage = lazy(() => import('./features/Dashboard/DashboardPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const ReportsPage = lazy(() => import('./features/Reports/ReportsPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const UnitsPage = lazy(() => import('./features/Units/UnitsPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const PersonsPage = lazy(() => import('./features/Persons/PersonsPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const ProjectsPage = lazy(() => import('./features/Projects/ProjectsPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const RequestTypesPage = lazy(() => import('./features/RequestTypes/RequestTypesPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const ChangePasswordPage = lazy(() => import('./features/Profile/ChangePasswordPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const WorkflowPage = lazy(() => import('./features/Workflow/WorkflowPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const InternalWorkflowPage = lazy(() => import('./features/InternalWorkflow/InternalWorkflowPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const RolesPage = lazy(() => import('./features/Roles/RolesPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const SecurityPage = lazy(() => import('./features/Security/SecurityPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const AppearancePage = lazy(() => import('./features/Appearance/AppearancePage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const PettyCashPage = lazy(() => import('./features/PettyCash/PettyCashPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const PettyCashManagementPage = lazy(() => import('./features/PettyCash/PettyCashManagementPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const ContractsPage = lazy(() => import('./features/Contracts/ContractsPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const DebitPage = lazy(() => import('./features/Debit/DebitPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const LoginPage = lazy(() => import('./pages/LoginPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const BackupRecoveryPage = lazy(() => import('./features/BackupRecovery/BackupRecoveryPage'));
// FIX: Replaced '@' alias with relative paths to resolve module errors.
const InvoiceExplorerPage = lazy(() => import('./features/InvoiceExplorer/InvoiceExplorerPage'));
const HelpPage = lazy(() => import('./features/Help/HelpPage'));
const AuditLogPage = lazy(() => import('./features/AuditLog/AuditLogPage'));
const SecurityOverviewPage = lazy(() => import('./features/Security/SecurityOverviewPage'));
const TipsManagementPage = lazy(() => import('./features/Tips/TipsManagementPage'));

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [isSidebarVisible, setIsSidebarVisible] = useState(true);
  const { status: serverStatus } = useServerStatus();

  return (
      <div className="flex h-screen overflow-hidden bg-gray-100 border-t-4 border-fuchsia-700">
        <Sidebar
          isSidebarVisible={isSidebarVisible}
          onHide={() => setIsSidebarVisible(false)}
        />
        <div
          className="flex-1 flex flex-col overflow-hidden transition-margin duration-300 ease-in-out"
          style={{ marginRight: isSidebarVisible ? '256px' : '0' }}
        >
          <Header
            onShowSidebar={() => setIsSidebarVisible(!isSidebarVisible)}
            userFullName={currentUser?.fullName}
            userPosition={currentUser?.position}
            serverStatus={serverStatus}
          />
          <main className="flex-grow p-4 sm:p-6 lg:p-8 overflow-y-auto">
            <Suspense fallback={<PageLoader />}>
                {children}
            </Suspense>
          </main>
        </div>
        <OfflineAiAssistant />
      </div>
  );
};

const App: React.FC = () => {
  const { isAuthenticated, currentUser } = useAuth();
  const [showTipModal, setShowTipModal] = useState(false);
  const [modalContent, setModalContent] = useState({ tip: '', avatar: '' });

  const { status: queryStatus, isFetching } = useQuery({
      queryKey: ['serverHealth'],
      queryFn: diagnosticsApi.healthCheck,
      refetchOnWindowFocus: true,
      retry: 1,
      staleTime: 0,
      gcTime: 15000,
  });
  
  const { data: tipsSettings } = useQuery({
      queryKey: ['tipsSettings'],
      queryFn: tipsApi.getSettings,
      enabled: isAuthenticated, // Only fetch if user is logged in
  });

  const serverStatus = useMemo<ServerStatus>(() => {
      if (queryStatus === 'error') return 'offline';
      if (isFetching) return 'checking';
      if (queryStatus === 'success') return 'online';
      return 'checking';
  }, [queryStatus, isFetching]);
  
  const serverStatusContextValue = useMemo(() => ({ status: serverStatus }), [serverStatus]);
  
  // PERFORMANCE: Removed global, unpaginated data fetching from the root component.
  // Data is now fetched by individual components as needed. This makes the initial
  // app load significantly faster and scales better with large datasets.
  const mainLayoutContextValue = useMemo<MainLayoutContextType>(() => ({
    units: [],
    roles: [],
    persons: [],
    requestCategories: [],
    internalWorkflows: [],
    isLoading: false, // This context no longer handles loading of this data.
  }), []);

  // Show "Tip of the Day" modal on first login per session.
  useEffect(() => {
    if (isAuthenticated && tipsSettings?.tips?.length) {
      const tipShown = sessionStorage.getItem('financialTipShown');
      if (!tipShown) {
        const randomIndex = Math.floor(Math.random() * tipsSettings.tips.length);
        setModalContent({
            tip: tipsSettings.tips[randomIndex],
            avatar: tipsSettings.avatar,
        });
        // Add a small delay to make it feel less abrupt on login
        const showTimer = setTimeout(() => {
            setShowTipModal(true);
        }, 1000); 
        sessionStorage.setItem('financialTipShown', 'true');

        return () => clearTimeout(showTimer);
      }
    }
  }, [isAuthenticated, tipsSettings]);

  // Security Enhancement: Disable developer tools for non-admin users.
  useEffect(() => {
    const isAdmin = currentUser?.roleIds?.includes(1); // Assuming '1' is the Admin Role ID

    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    const handleKeyDown = (e: KeyboardEvent) => {
        // Disable F12
        if (e.key === 'F12') {
            e.preventDefault();
        }
        // Disable Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C
        if (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(e.key.toUpperCase())) {
            e.preventDefault();
        }
        // Disable Ctrl+U
        if (e.ctrlKey && e.key.toUpperCase() === 'U') {
            e.preventDefault();
        }
    };

    if (isAuthenticated && !isAdmin) {
        document.addEventListener('contextmenu', handleContextMenu);
        document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
        document.removeEventListener('contextmenu', handleContextMenu);
        document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isAuthenticated, currentUser]);


  return (
    <ServerStatusContext.Provider value={serverStatusContextValue}>
      <MainLayoutContext.Provider value={mainLayoutContextValue}>
        {showTipModal && (
            <FinancialTipModal 
                tip={modalContent.tip}
                avatarSrc={modalContent.avatar}
                onClose={() => setShowTipModal(false)}
            />
        )}
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" /> : <LoginPage />} />
            <Route path="/*" element={
              <ProtectedRoute>
                <MainLayout>
                  <Routes>
                      <Route path="/" element={<Navigate to="/dashboard" />} />
                      <Route path="/welcome" element={<WelcomePage />} />
                      <Route path="/dashboard" element={<DashboardPage />} />
                      <Route path="/reports" element={<ReportsPage />} />
                      <Route path="/invoice-explorer" element={<InvoiceExplorerPage />} />
                      <Route path="/my-petty-cash" element={<PettyCashPage />} />
                      <Route path="/contracts" element={<ContractsPage />} />
                      <Route path="/debit-cards" element={<DebitPage />} />
                      <Route path="/units" element={<UnitsPage />} />
                      <Route path="/persons" element={<PersonsPage />} />
                      <Route path="/projects" element={<ProjectsPage />} />
                      <Route path="/request-types" element={<RequestTypesPage />} />
                      <Route path="/profile" element={<ChangePasswordPage />} />
                      <Route path="/workflow" element={<WorkflowPage />} />
                      <Route
                        path="/internal-workflows"
                        element={<InternalWorkflowPage />}
                      />
                      <Route path="/roles" element={<RolesPage />} />
                      <Route path="/security" element={<SecurityPage />} />
                      <Route path="/security-overview" element={<SecurityOverviewPage />} />
                      <Route path="/audit-log" element={<AuditLogPage />} />
                      <Route path="/appearance" element={<AppearancePage />} />
                      <Route path="/petty-cash-management" element={<PettyCashManagementPage />} />
                      <Route path="/tips-management" element={<TipsManagementPage />} />
                      <Route path="/backup-recovery" element={<BackupRecoveryPage />} />
                      <Route path="/help" element={<HelpPage />} />
                      <Route path="*" element={<Navigate to="/dashboard" />} />
                    </Routes>
                </MainLayout>
              </ProtectedRoute>
            } />
          </Routes>
        </Suspense>
      </MainLayoutContext.Provider>
    </ServerStatusContext.Provider>
  );
};

export default App;