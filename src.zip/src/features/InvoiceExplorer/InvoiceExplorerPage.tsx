



import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm, SubmitHandler } from 'react-hook-form';

// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { PaginatedResponse, SupplyRequest, InvoiceExplorerItem } from '../../types';
import { DataTable, ColumnDef } from '../../components/DataTable';
import RequestDetailsModal from '../Dashboard/RequestDetailsModal';
import { formatCurrency } from '../../utils/formatters';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useMainLayoutContext } from '../../context/MainLayoutContext';
import { reportsApi } from '../../services/api';
import { useAuth } from '../../hooks/useAuth';
import { useServerStatus } from '../../context/ServerStatusContext';

type SearchFormData = {
  q: string;
  beneficiaryId: string;
  requestingUnitId: string;
  dateFrom: string; 
  dateTo: string;
  priceFrom: number | '';
  priceTo: number | '';
  fundingSource: string;
  expenseType: string;
};

const InvoiceExplorerPage: React.FC = () => {
    const { read: canRead } = usePermissions('INVOICE_EXPLORER');
    const { currentUser } = useAuth();
    const queryClient = useQueryClient();

    const { units, persons, isLoading: isContextLoading } = useMainLayoutContext();
    const beneficiaries = useMemo(() => persons.filter(p => p.isBeneficiary), [persons]);

    const { status: serverStatus } = useServerStatus();
    const isServerOffline = serverStatus === 'offline';

    const [searchFilters, setSearchFilters] = useState<Partial<SearchFormData>>({});
    const [viewingRequestId, setViewingRequestId] = useState<string | null>(null);
    const [page, setPage] = useState(1);

    const { register, handleSubmit, reset, watch } = useForm<SearchFormData>();
    const watchedDateFrom = watch('dateFrom');
    const watchedDateTo = watch('dateTo');

    const { data: searchResponse, isLoading: isSearchLoading } = useQuery<PaginatedResponse<InvoiceExplorerItem>>({
        queryKey: ['invoice_items_list', searchFilters, page],
        queryFn: () => reportsApi.searchInvoiceItems({ ...searchFilters }, page),
        enabled: !!searchFilters && !!currentUser && serverStatus === 'online',
    });

    const onSubmit: SubmitHandler<SearchFormData> = (data) => {
        const cleanedData = Object.fromEntries(
            Object.entries(data).filter(([, value]) => value !== '' && value !== null && value !== undefined)
        ) as Partial<SearchFormData>;
        setPage(1);
        setSearchFilters(cleanedData);
    };

    const clearSearch = () => {
        const emptyFilters: SearchFormData = { q: '', beneficiaryId: '', requestingUnitId: '', dateFrom: '', dateTo: '', priceFrom: '', priceTo: '', fundingSource: '', expenseType: '' };
        reset(emptyFilters);
        setSearchFilters({});
        setPage(1);
    };
    
    const columns: ColumnDef<InvoiceExplorerItem>[] = [
        { accessorKey: 'description', header: 'شرح کالا/خدمت' },
        { accessorKey: 'quantity', header: 'تعداد' },
        { accessorKey: 'unitPrice', header: 'قیمت واحد', cell: (item) => formatCurrency(item.unitPrice, item.currency) },
        { accessorKey: 'beneficiaryName', header: 'ذی‌نفع (فروشنده)' },
        { accessorKey: 'requestingUnitName', header: 'واحد درخواست‌کننده' },
        { accessorKey: 'submissionDate', header: 'تاریخ درخواست' },
        { accessorKey: 'requestId', header: 'شماره درخواست', cell: (item) => <button onClick={() => setViewingRequestId(item.requestId)} className="text-blue-600 hover:underline font-semibold font-mono">{item.requestId}</button> }
    ];

    if (!canRead) return <AccessDenied />;
    
    const isLoading = isContextLoading;
    if (isLoading && serverStatus !== 'offline') return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div></div>;
    
    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">کاوشگر اقلام فاکتور</h2>

            <details className="p-4 bg-white rounded-lg border shadow-sm space-y-4" open>
                <summary className="font-semibold cursor-pointer">جستجوی پیشرفته اقلام</summary>
                <form onSubmit={handleSubmit(onSubmit)} className="mt-4 pt-4 border-t space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div className="lg:col-span-2"><label className="text-sm block mb-1">شرح کالا/خدمت</label><input {...register('q')} className="w-full border p-2 rounded text-sm" placeholder="مثال: هارد دیسک" /></div>
                        <div><label className="text-sm block mb-1">ذی‌نفع (فروشنده)</label><select {...register('beneficiaryId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{beneficiaries.map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}</select></div>
                        <div><label className="text-sm block mb-1">واحد درخواست‌کننده</label><select {...register('requestingUnitId')} className="w-full border p-2 rounded text-sm bg-white"><option value="">همه</option>{units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select></div>
                        <div>
                            <label className="text-sm block mb-1">تاریخ ثبت (از)</label>
                            <input type="date" {...register('dateFrom')} className="w-full border p-2 rounded text-sm"/>
                            {watchedDateFrom && <div className="text-sm font-semibold text-gray-700 mt-1 text-center">{new Date(watchedDateFrom).toLocaleDateString('fa-IR')}</div>}
                        </div>
                        <div>
                            <label className="text-sm block mb-1">تاریخ ثبت (تا)</label>
                            <input type="date" {...register('dateTo')} className="w-full border p-2 rounded text-sm"/>
                            {watchedDateTo && <div className="text-sm font-semibold text-gray-700 mt-1 text-center">{new Date(watchedDateTo).toLocaleDateString('fa-IR')}</div>}
                        </div>
                        <div><label className="text-sm block mb-1">قیمت واحد (از)</label><input type="number" {...register('priceFrom')} className="w-full border p-2 rounded text-sm"/></div>
                        <div><label className="text-sm block mb-1">قیمت واحد (تا)</label><input type="number" {...register('priceTo')} className="w-full border p-2 rounded text-sm"/></div>
                        <div>
                            <label className="text-sm block mb-1">منبع اعتبار</label>
                            <select {...register('fundingSource')} className="w-full border p-2 rounded text-sm bg-white">
                                <option value="">همه</option>
                                <option value="PRODUCTION">تولیدی</option>
                                <option value="RESEARCH">تحقیقاتی</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-sm block mb-1">نوع هزینه</label>
                            <select {...register('expenseType')} className="w-full border p-2 rounded text-sm bg-white">
                                <option value="">همه</option>
                                <option value="CAPITAL">سرمایه‌ای</option>
                                <option value="CONSUMABLE">مصرفی</option>
                            </select>
                        </div>
                    </div>
                    <div className="flex justify-end items-center gap-2 pt-4 border-t">
                        <button type="button" onClick={clearSearch} className="bg-gray-200 text-gray-800 px-6 py-2 rounded-md font-semibold hover:bg-gray-300">پاک کردن</button>
                        <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700">جستجو</button>
                    </div>
                </form>
            </details>

            <div className="mt-6">
                <h3 className="text-xl font-bold text-gray-800 mb-4">
                    نتایج جستجو {isSearchLoading && serverStatus !== 'offline' ? '(در حال بارگذاری...)' : ''}
                </h3>
                {isSearchLoading && serverStatus !== 'offline' ? (
                    <div className="text-center p-8">
                        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
                        <p className="mt-4 text-gray-600">در حال بارگذاری نتایج...</p>
                    </div>
                ) : (
                    <DataTable
                        columns={columns}
                        data={searchResponse?.data || []}
                        pagination={{ page, total: searchResponse?.total || 0, itemsPerPage: 20 }}
                        onPageChange={setPage}
                    />
                )}
            </div>

            {viewingRequestId && currentUser && (
// FIX: The RequestDetailsModal expects a `requestId` string prop, not a `request` object.
// The redundant local fetch and loading state have been removed as the modal handles its own data fetching.
                <RequestDetailsModal
                    requestId={viewingRequestId}
                    onClose={() => setViewingRequestId(null)}
                    onActionComplete={() => {
                        setViewingRequestId(null);
                        queryClient.invalidateQueries({ queryKey: ['invoice_items_list'] });
                    }}
                    loggedInUserId={currentUser.id}
                    isServerOffline={isServerOffline}
                />
            )}
        </div>
    );
};

export default InvoiceExplorerPage;