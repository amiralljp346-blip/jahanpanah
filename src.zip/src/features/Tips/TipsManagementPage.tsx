import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { tipsApi } from '../../services/api';
import { TipsSettings } from '../../types';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useAuth } from '../../hooks/useAuth';

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const defaultAvatarSvgString = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <circle cx="50" cy="50" r="48" fill="#e0e0e0" stroke="#bdbdbd" stroke-width="2"/>
  <path d="M50,60 C70,60 70,40 50,40 C30,40 30,60 50,60 Z" fill="#bdbdbd"/>
  <path d="M50,65 C30,65 25,85 50,85 C75,85 70,65 50,65 Z" fill="#bdbdbd"/>
</svg>`;
const DEFAULT_AVATAR_SVG = `data:image/svg+xml;base64,${btoa(defaultAvatarSvgString)}`;

const TipsManagementPage: React.FC = () => {
    const { read: canRead, update: canUpdate } = usePermissions('APPEARANCE');
    const queryClient = useQueryClient();
    const { currentUser } = useAuth();
    const [localSettings, setLocalSettings] = useState<TipsSettings | null>(null);
    const [newTip, setNewTip] = useState('');
    const [editingIndex, setEditingIndex] = useState<number | null>(null);
    const [editingText, setEditingText] = useState('');
    const toast = useToast();

    const { data: settings, isLoading } = useQuery<TipsSettings>({
        queryKey: ['tipsSettings'],
        queryFn: tipsApi.getSettings,
        enabled: canRead,
    });

    useEffect(() => {
        if (settings) {
            setLocalSettings(JSON.parse(JSON.stringify(settings)));
        }
    }, [settings]);

    const mutation = useMutation({
        mutationFn: (updatedSettings: TipsSettings) => tipsApi.updateSettings({ settings: updatedSettings, actingUserId: currentUser!.id }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tipsSettings'] });
            toast.success('تنظیمات با موفقیت ذخیره شد.');
        },
        onError: (error: Error) => toast.error(`خطا در ذخیره سازی: ${error.message}`),
    });

    const handleAddTip = () => {
        if (newTip.trim() && localSettings) {
            setLocalSettings({ ...localSettings, tips: [...localSettings.tips, newTip.trim()] });
            setNewTip('');
        }
    };

    const handleUpdateTip = (index: number) => {
        if (editingText.trim() && localSettings) {
            const updatedTips = [...localSettings.tips];
            updatedTips[index] = editingText.trim();
            setLocalSettings({ ...localSettings, tips: updatedTips });
            setEditingIndex(null);
            setEditingText('');
        }
    };
    
    const handleDeleteTip = (index: number) => {
        if (localSettings && window.confirm('آیا از حذف این نکته مطمئن هستید؟')) {
            const updatedTips = localSettings.tips.filter((_, i) => i !== index);
            setLocalSettings({ ...localSettings, tips: updatedTips });
        }
    };

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && localSettings) {
            try {
                const url = await fileToBase64(file);
                setLocalSettings({ ...localSettings, avatar: url });
            } catch (error) {
                toast.error('خطا در بارگذاری تصویر.');
            }
        }
    };

    const handleSave = () => {
        if (localSettings) {
            mutation.mutate(localSettings);
        }
    };

    if (!canRead) return <AccessDenied />;
    if (isLoading || !localSettings) return <p>در حال بارگذاری تنظیمات...</p>;

    return (
        <div className="space-y-6 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800">مدیریت نکات روز</h2>

            <div className="bg-white p-6 rounded-lg shadow-sm border">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">تصویر پروفایل</h3>
                <div className="flex items-center gap-6">
                    <img src={localSettings.avatar || DEFAULT_AVATAR_SVG} alt="Avatar Preview" className="w-24 h-24 rounded-full border-4 border-gray-200" />
                    <div>
                        <p className="text-sm text-gray-600 mb-2">تصویری را که می‌خواهید کنار نکات نمایش داده شود، آپلود کنید.</p>
                        <label className="bg-blue-100 text-blue-800 px-4 py-2 rounded-lg font-semibold text-sm cursor-pointer hover:bg-blue-200">
                            انتخاب تصویر
                            <input type="file" onChange={handleImageUpload} accept="image/*" className="hidden" disabled={!canUpdate} />
                        </label>
                    </div>
                </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">لیست نکات و قوانین مالی</h3>
                <div className="space-y-2 mb-4">
                    {localSettings.tips.map((tip, index) => (
                        <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded-md">
                            {editingIndex === index ? (
                                <input value={editingText} onChange={(e) => setEditingText(e.target.value)} className="flex-grow border p-1 rounded" />
                            ) : (
                                <p className="flex-grow text-sm text-gray-700">{tip}</p>
                            )}
                            
                            {editingIndex === index ? (
                                <button onClick={() => handleUpdateTip(index)} className="text-green-600 font-semibold text-sm">ذخیره</button>
                            ) : (
                                <button onClick={() => { setEditingIndex(index); setEditingText(tip); }} disabled={!canUpdate} className="text-blue-600 font-semibold text-sm disabled:text-gray-400">ویرایش</button>
                            )}
                            <button onClick={() => handleDeleteTip(index)} disabled={!canUpdate} className="text-red-600 font-semibold text-sm disabled:text-gray-400">حذف</button>
                        </div>
                    ))}
                </div>
                {canUpdate && (
                    <div className="flex gap-2 border-t pt-4">
                        <input value={newTip} onChange={(e) => setNewTip(e.target.value)} placeholder="نکته جدید را اینجا بنویسید..." className="w-full border p-2 rounded" />
                        <button onClick={handleAddTip} className="bg-green-600 text-white px-4 py-2 rounded font-semibold whitespace-nowrap">افزودن</button>
                    </div>
                )}
            </div>
            
            <div className="flex justify-end pt-6 border-t mt-6">
                <button onClick={handleSave} disabled={!canUpdate || mutation.isPending} className="bg-fuchsia-600 text-white px-8 py-2.5 rounded-lg font-semibold hover:bg-fuchsia-700 shadow-md disabled:bg-gray-400">
                    {mutation.isPending ? 'در حال ذخیره...' : 'ذخیره تمام تغییرات'}
                </button>
            </div>
        </div>
    );
};

export default TipsManagementPage;