import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Contract, PaginatedResponse, Person } from '../../types';
import { contractsApi, personsApi } from '../../services/api';
import { DataTable, ColumnDef } from '../../components/DataTable';
import ContractForm from './ContractForm';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { formatCurrency } from '../../utils/formatters';
import { useServerStatus } from '../../context/ServerStatusContext';

const getStatusBadge = (status: Contract['status']) => {
    const statusMap = {
        'DRAFT': { text: 'پیش‌نویس', color: 'gray' },
        'ACTIVE': { text: 'فعال', color: 'green' },
        'COMPLETED': { text: 'تکمیل شده', color: 'fuchsia' },
        'TERMINATED': { text: 'خاتمه یافته', color: 'red' },
    };
    const s = statusMap[status] || { text: status, color: 'gray' };
    return <span className={`bg-${s.color}-100 text-${s.color}-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full`}>{s.text}</span>;
};


const ContractsPage: React.FC = () => {
    const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('CONTRACTS');
    const queryClient = useQueryClient();
    const toast = useToast();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingContract, setEditingContract] = useState<Contract | null>(null);
    const { status: serverStatus } = useServerStatus();
    
    const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({
        queryKey: ['persons_beneficiaries'],
        queryFn: () => personsApi.getAllUnpaginated({ isBeneficiary: true }),
        enabled: serverStatus === 'online',
    });

    const { data: contractsResponse, isLoading: isContractsLoading } = useQuery<PaginatedResponse<Contract>>({
        queryKey: ['contracts', page, debouncedSearch],
        queryFn: () => contractsApi.getAll(page, debouncedSearch),
        placeholderData: (previousData) => previousData,
        enabled: serverStatus === 'online',
    });

    useEffect(() => {
        setPage(1);
    }, [debouncedSearch]);
    
    const deleteMutation = useMutation({
        mutationFn: (id: number) => contractsApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['contracts'] });
            toast.success('قرارداد با موفقیت حذف شد.');
        },
        onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`),
    });

    const openModal = (contract: Contract | null = null) => {
        setEditingContract(contract);
        setIsModalOpen(true);
    };
    
    const handleDelete = (id: number) => {
        if (window.confirm('آیا از حذف این قرارداد مطمئن هستید؟')) {
            deleteMutation.mutate(id);
        }
    };

    const columns: ColumnDef<Contract>[] = [
        { accessorKey: 'contractNumber', header: 'شماره قرارداد' },
        { accessorKey: 'contractTitle', header: 'عنوان قرارداد' },
        { accessorKey: 'partyName', header: 'طرف قرارداد' },
        {
            accessorKey: 'contractAmount',
            header: 'مبلغ کل',
            cell: (c) => formatCurrency(c.contractAmount, 'RIAL'),
        },
        { 
            accessorKey: 'contractDate', 
            header: 'تاریخ امضا',
            cell: (c) => c.contractDate ? new Date(c.contractDate).toLocaleDateString('fa-IR') : '---',
        },
        { accessorKey: 'status', header: 'وضعیت', cell: (c) => getStatusBadge(c.status) },
        {
            accessorKey: 'actions',
            header: 'عملیات',
            width: '120px',
            cell: (contract) => (
                <div className="flex justify-center gap-4">
                    <button
                        onClick={() => openModal(contract)}
                        disabled={!canUpdate}
                        className="text-fuchsia-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline"
                    >
                        ویرایش
                    </button>
                    <button
                        onClick={() => handleDelete(contract.id)}
                        disabled={!canDelete}
                        className="text-red-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline"
                    >
                        حذف
                    </button>
                </div>
            ),
        },
    ];

    if (!canRead) return <AccessDenied />;

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">مدیریت قراردادها</h2>
                <button
                    onClick={() => openModal()}
                    disabled={!canCreate}
                    className="bg-fuchsia-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-fuchsia-700 disabled:bg-gray-400"
                >
                    ثبت قرارداد جدید
                </button>
            </div>

            <div className="relative">
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس شماره یا عنوان قرارداد..."
                    className="w-full p-2 pl-10 border rounded-md"
                />
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
            </div>

            {(isContractsLoading || isPersonsLoading) && serverStatus !== 'offline' ? (
                <p>در حال بارگذاری...</p>
            ) : (
                <DataTable
                    columns={columns}
                    data={contractsResponse?.data || []}
                    pagination={{ page, total: contractsResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            )}

            {isModalOpen && (
                <ContractForm
                    contract={editingContract}
                    persons={persons || []}
                    onClose={() => setIsModalOpen(false)}
                />
            )}
        </section>
    );
};

export default ContractsPage;
