
import React, { useState, useEffect, useMemo } from 'react';
import { useForm, useFieldArray, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { z } from 'zod';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { InternalWorkflow, InternalWorkflowSchema, InternalWorkflowData, PaginatedResponse, Person, Unit } from '../../types';
import { internalWorkflowsApi, personsApi, unitsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { useServerStatus } from '../../context/ServerStatusContext';

type WorkflowFormData = z.infer<typeof InternalWorkflowSchema>;

const InternalWorkflowPage: React.FC = () => {
  const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('INTERNAL_WORKFLOWS');
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState<InternalWorkflow | null>(null);
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearch = useDebounce(searchQuery, 300);
  const { status: serverStatus } = useServerStatus();

  const { data: workflowsResponse, isLoading: isWorkflowsLoading } = useQuery<PaginatedResponse<InternalWorkflow>>({
      queryKey: ['internalWorkflows', page, debouncedSearch],
      queryFn: () => internalWorkflowsApi.getAll(page, debouncedSearch),
      placeholderData: (previousData) => previousData,
      enabled: serverStatus === 'online',
  });

  const { data: units, isLoading: isUnitsLoading } = useQuery<Unit[]>({ queryKey: ['units_all'], queryFn: () => unitsApi.getAllUnpaginated(), enabled: serverStatus === 'online' });
  const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({ queryKey: ['persons_all'], queryFn: () => personsApi.getAllUnpaginated(), enabled: serverStatus === 'online' });
  
  const { register, control, handleSubmit, reset, watch, formState: { errors } } = useForm<WorkflowFormData>({ resolver: zodResolver(InternalWorkflowSchema), defaultValues: { name: '', unitId: '', steps: [{ name: '', assigneeId: '' }] } });
  const { fields, append, remove } = useFieldArray({ control, name: "steps" });
  const watchedUnitId = watch("unitId");

  const availableAssignees = useMemo(() => watchedUnitId && persons ? (persons || []).filter(p => p.unitId === Number(watchedUnitId) && p.isSystemUser) : [], [watchedUnitId, persons]);
  
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch]);
  
  useEffect(() => {
    if (isModalOpen) {
        if (selectedWorkflow) reset({ name: selectedWorkflow.name, unitId: String(selectedWorkflow.unitId), steps: selectedWorkflow.steps.map(s => ({ ...s, assigneeId: String(s.assigneeId) })) });
        else reset({ name: '', unitId: '', steps: [{ name: '', assigneeId: '' }] });
    }
  }, [selectedWorkflow, isModalOpen, reset]);

  const mutation = useMutation({
    mutationFn: (data: { formData: WorkflowFormData, id?: number }) => {
        const finalData: InternalWorkflowData = { name: data.formData.name, unitId: Number(data.formData.unitId), steps: data.formData.steps.map((step, index) => ({ id: selectedWorkflow?.steps[index]?.id || Date.now() + index, name: step.name, assigneeId: Number(step.assigneeId) })) };
        return data.id ? internalWorkflowsApi.update(data.id, finalData) : internalWorkflowsApi.create(finalData);
    },
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ['internalWorkflows'] }); 
      setIsModalOpen(false);
      toast.success('فرآیند داخلی با موفقیت ذخیره شد.');
    },
    onError: (err: Error) => toast.error(`خطا در ذخیره سازی: ${err.message}`)
  });

  const deleteMutation = useMutation({ 
    mutationFn: (id: number) => internalWorkflowsApi.delete(id), 
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['internalWorkflows'] });
      toast.success('فرآیند داخلی با موفقیت حذف شد.');
    }, 
    onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`) 
  });

  const onSubmit: SubmitHandler<WorkflowFormData> = (data) => mutation.mutate({ formData: data, id: selectedWorkflow?.id });
  const handleDelete = (id: number) => { if (window.confirm('آیا از حذف این فرآیند مطمئن هستید؟')) deleteMutation.mutate(id); };
  const openModal = (wf: InternalWorkflow | null = null) => { setSelectedWorkflow(wf); setIsModalOpen(true); };

  const columns: ColumnDef<InternalWorkflow>[] = [
    { accessorKey: 'name', header: 'نام فرآیند داخلی' },
    { accessorKey: 'unitId', header: 'مربوط به واحد', cell: (wf) => (units || []).find(u => u.id === wf.unitId)?.name || '---' },
    { accessorKey: 'steps', header: 'مراحل', cell: (wf) => <div className="text-xs">{(wf.steps || []).map(s => `${s.name} (${(persons || []).find(p => p.id === s.assigneeId)?.fullName || 'ناشناس'})`).join(' ← ')}</div>},
    { accessorKey: 'actions', header: 'عملیات', cell: (wf) => (<div className="flex justify-center gap-4 text-sm"><button onClick={() => openModal(wf)} disabled={!canUpdate} className="text-blue-600 font-semibold hover:underline disabled:text-gray-400 disabled:no-underline">ویرایش</button><button onClick={() => handleDelete(wf.id)} disabled={!canDelete} className="text-red-600 font-semibold hover:underline disabled:text-gray-400 disabled:no-underline">حذف</button></div>) }
  ];
  
  if (!canRead) return <AccessDenied />;

  const isLoading = isWorkflowsLoading || isUnitsLoading || isPersonsLoading;

  return (
    <section className="space-y-6">
      <div className="flex justify-between items-center"><h2 className="text-2xl font-bold text-gray-800">مدیریت فرآیندهای داخلی واحدها</h2><button onClick={() => openModal()} disabled={!canCreate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 disabled:bg-gray-400">افزودن فرآیند جدید</button></div>
      
       <div className="relative">
          <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو بر اساس نام فرآیند..."
              className="w-full p-2 pl-10 border rounded-md"
          />
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
      </div>

      {isLoading && serverStatus !== 'offline' ? <p>در حال بارگذاری...</p> : 
        <DataTable 
            columns={columns} 
            data={workflowsResponse?.data || []}
            pagination={{ page, total: workflowsResponse?.total || 0, itemsPerPage: 20 }}
            onPageChange={setPage}
        />
      }
      {isModalOpen && <Modal title={selectedWorkflow ? "ویرایش فرآیند داخلی" : "ایجاد فرآیند داخلی جدید"} onClose={() => setIsModalOpen(false)} size="2xl"><form onSubmit={handleSubmit(onSubmit)} className="space-y-4 max-h-[70vh] overflow-y-auto p-6"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-sm font-medium text-gray-700 mb-1">نام فرآیند</label><input {...register("name")} className="w-full border p-2 rounded" />{errors.name && <p className="text-red-500 text-xs">{errors.name.message as string}</p>}</div><div><label className="block text-sm font-medium text-gray-700 mb-1">برای واحد سازمانی</label><select {...register("unitId")} className="w-full border p-2 rounded bg-white"><option value="">...</option>{(units || []).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select>{errors.unitId && <p className="text-red-500 text-xs">{errors.unitId.message as string}</p>}</div></div><div className="pt-4 border-t"><h3 className="font-semibold mb-2">گام‌های فرآیند (به ترتیب اجرا)</h3><div className="space-y-2">{fields.map((field, index) => <div key={field.id} className="grid grid-cols-[auto_1fr_1fr_auto] items-center gap-2 p-2 border rounded"><span className="font-bold text-gray-500">{index + 1}</span><input {...register(`steps.${index}.name`)} placeholder="نام گام" className="border p-1 rounded w-full" /><select {...register(`steps.${index}.assigneeId`)} className="border p-1 rounded bg-white text-sm" disabled={!watchedUnitId}><option value="">انتخاب مسئول</option>{availableAssignees.map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}</select><button type="button" onClick={() => remove(index)} className="text-red-500 font-bold hover:text-red-700">✖</button></div>)}</div><button type="button" onClick={() => append({ name: '', assigneeId: '' })} className="text-sm text-blue-600 mt-2 font-semibold hover:underline">+ افزودن گام</button>{errors.steps && <p className="text-red-500 text-xs mt-1">{(errors.steps.message || (errors.steps as any).root?.message) as string}</p>}</div><div className="flex justify-end gap-2 pt-4 border-t mt-2"><button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? '...' : 'ذخیره'}</button></div></form></Modal>}
    </section>
  );
};

export default InternalWorkflowPage;