
import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
// FIX: Using a namespace import for react-router-dom to work around module resolution issues.
import * as ReactRouterDOM from 'react-router-dom';
const { Link } = ReactRouterDOM;
import { personsApi } from '../../services/api';
import { Person, PaginatedResponse, PETTY_CASH_ROLE_ID } from '../../types';
import AccessDenied from '../../components/AccessDenied';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { useDebounce } from '../../hooks/useDebounce';
import { useToast } from '../../hooks/useToast';
import { formatCurrency } from '../../utils/formatters';
import Modal from '../../components/Modal';
// FIX: Replaced '@' alias with relative path and removed file extension.
import { useAuth } from '../../hooks/useAuth';
import { useServerStatus } from '../../context/ServerStatusContext';

const PettyCashManagementPage: React.FC = () => {
    const { currentUser } = useAuth();
    const userPermissions = useMemo(() => new Set(currentUser?.permissions || []), [currentUser]);
    
    const canReadAll = userPermissions.has('PETTY_CASH_MANAGEMENT:read_all');
    const canReadOwn = userPermissions.has('PETTY_CASH_MANAGEMENT:read_own_unit');
    const canUpdate = userPermissions.has('PETTY_CASH_MANAGEMENT:update');

    const queryClient = useQueryClient();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const toast = useToast();
    const [isLimitModalOpen, setIsLimitModalOpen] = useState(false);
    const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
    const [newLimit, setNewLimit] = useState(0);
    const { status: serverStatus } = useServerStatus();

    const { data: personsResponse, isLoading: isPersonsLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['persons_petty_cash_holders', page, debouncedSearch, currentUser?.id],
        queryFn: () => personsApi.getAll(page, debouncedSearch, { 
            isPettyCashHolder: true, 
            actingUserId: currentUser!.id 
        }),
        enabled: !!currentUser && (canReadAll || canReadOwn) && serverStatus === 'online',
    });

    useEffect(() => { setPage(1); }, [debouncedSearch]);

    const limitMutation = useMutation({
        mutationFn: (data: { personId: number; limit: number }) => 
            personsApi.update(data.personId, { 
                pettyCashLimit: data.limit, 
                pettyCashBalance: data.limit,
                actingUserId: currentUser!.id,
            }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['persons_petty_cash_holders'] });
            setIsLimitModalOpen(false);
            toast.success('سقف اعتبار با موفقیت به‌روزرسانی شد.');
        },
        onError: (error: Error) => toast.error(`خطا: ${error.message}`),
    });

    const handleOpenLimitModal = (person: Person) => {
        setSelectedPerson(person);
        setNewLimit(person.pettyCashLimit || 0);
        setIsLimitModalOpen(true);
    };
    
    const handleSetLimit = () => {
        if (selectedPerson) {
            limitMutation.mutate({ personId: selectedPerson.id, limit: newLimit });
        }
    };

    const columns: ColumnDef<Person>[] = [
        { accessorKey: 'fullName', header: 'نام تنخواه بگیر' },
        { accessorKey: 'unitName', header: 'واحد خدمتی' },
        { accessorKey: 'pettyCashLimit', header: 'سقف اعتبار', cell: (p) => formatCurrency(p.pettyCashLimit, 'RIAL') },
        { accessorKey: 'pettyCashBalance', header: 'موجودی باقیمانده', cell: (p) => formatCurrency(p.pettyCashBalance, 'RIAL') },
        { accessorKey: 'actions', header: 'عملیات', width: '150px', cell: (person) => (
            <div className="flex justify-center">
                <button onClick={() => handleOpenLimitModal(person)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400">تخصیص اعتبار</button>
            </div>
        )},
    ];
    
    if (!canReadAll && !canReadOwn) return <AccessDenied />;

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">مدیریت تنخواه</h2>
            </div>
            
            <div className="relative">
                <input
                    type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس نام تنخواه بگیر..."
                    className="w-full p-2 pl-10 border rounded-md"
                />
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            
            {isPersonsLoading && serverStatus !== 'offline' ? <p>در حال بارگذاری...</p> : 
                (personsResponse?.data && personsResponse.data.length > 0) ? (
                    <DataTable
                        columns={columns}
                        data={personsResponse.data}
                        pagination={{ page, total: personsResponse.total || 0, itemsPerPage: 20 }}
                        onPageChange={setPage}
                    />
                ) : (
                    <div className="text-center p-12 bg-gray-50 rounded-lg border">
                        <h3 className="font-semibold text-gray-700">هیچ تنخواه بگیری یافت نشد.</h3>
                        <p className="text-sm text-gray-500 mt-2 max-w-md mx-auto">
                            برای مدیریت اعتبار تنخواه، ابتدا باید برای اشخاص مورد نظر <strong>سقف اعتبار تنخواه</strong> تعریف شده باشد. شما می‌توانید از صفحه <Link to="/security" className="text-blue-600 font-semibold hover:underline">کاربران و امنیت</Link> هنگام تخصیص نقش «تنخواه گردان»، این سقف را مشخص کنید.
                        </p>
                    </div>
                )
            }
            
            {isLimitModalOpen && selectedPerson && (
                <Modal title={`تخصیص اعتبار برای ${selectedPerson.fullName}`} onClose={() => setIsLimitModalOpen(false)} size="sm">
                    <div className="p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">سقف اعتبار جدید (ریال)</label>
                            <input type="number" value={newLimit} onChange={(e) => setNewLimit(Number(e.target.value))} className="w-full border p-2 rounded" autoFocus />
                        </div>
                        <p className="text-xs text-gray-500">توجه: با تخصیص سقف جدید، موجودی فعلی فرد نیز به این مبلغ بازنشانی خواهد شد.</p>
                    </div>
                    <div className="flex justify-end gap-2 p-4 bg-gray-50 border-t">
                        <button type="button" onClick={() => setIsLimitModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button>
                        <button onClick={handleSetLimit} disabled={limitMutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">ذخیره</button>
                    </div>
                </Modal>
            )}
        </section>
    );
};

export default PettyCashManagementPage;