
import React from 'react';
// FIX: Replaced '@' alias with a relative path to resolve module resolution error.
import { SupplyRequest } from '../../types';

interface ProcessStepperProps {
  request: SupplyRequest;
}

const ProcessStepper: React.FC<ProcessStepperProps> = ({ request }) => {
  const { workflow, status, _activeSteps = [] } = request;

  if (!workflow?.steps) {
    return <p className="text-center text-gray-500 text-sm">اطلاعات فرآیند در دسترس نیست.</p>;
  }

  const activeStepId = status === 'IN_REVIEW' ? _activeSteps[0]?.stepId : null;
  const activeStepIndex = activeStepId ? workflow.steps.findIndex(s => s.id === activeStepId) : -1;

  return (
    <div className="flex items-start justify-between w-full p-4 overflow-x-auto">
      {workflow.steps.map((step, index) => {
        let isCompleted = false;
        if (status === 'APPROVED') {
            isCompleted = true;
        } else if (status === 'IN_REVIEW') {
            isCompleted = activeStepIndex > index;
        } else if (status === 'REJECTED') {
            // FIX: Corrected unintentional type comparison. The action type is 'REJECT', not 'REJECTED'.
            const rejectionHistory = request._history.find(h => h.action === 'REJECT');
            if (rejectionHistory) {
                const rejectionStepIndex = workflow.steps.findIndex(s => s.id === rejectionHistory.stepId);
                isCompleted = index < rejectionStepIndex;
            }
        }

        const isActive = index === activeStepIndex;
        
        let circleClasses = '';
        if (isCompleted) {
            circleClasses = 'bg-green-500 text-white';
        } else if (isActive) {
            circleClasses = 'bg-fuchsia-600 text-white ring-4 ring-fuchsia-200';
        } else {
            circleClasses = 'bg-gray-200 text-gray-500';
        }

        // FIX: Corrected unintentional type comparison. The action type is 'REJECT', not 'REJECTED'.
        const isRejectedAtThisStep = status === 'REJECTED' && request._history.some(h => h.action === 'REJECT' && h.stepId === step.id);
        if (isRejectedAtThisStep) {
            circleClasses = 'bg-red-500 text-white';
        }
        
        return (
            <React.Fragment key={step.id}>
                <div className="flex flex-col items-center text-center w-28 flex-shrink-0">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300 ${circleClasses}`}>
                        {isCompleted ? '✓' : isRejectedAtThisStep ? '✕' : index + 1}
                    </div>
                    <p className={`mt-2 text-xs font-semibold ${isActive ? 'text-fuchsia-600' : 'text-gray-700'}`}>
                        {step.name}
                    </p>
                </div>
                {index < workflow.steps.length - 1 && (
                    <div className={`flex-1 h-0.5 mt-4 mx-1 rounded ${isCompleted ? 'bg-green-500' : 'bg-gray-200'}`} />
                )}
            </React.Fragment>
        );
      })}
    </div>
  );
};

export default ProcessStepper;