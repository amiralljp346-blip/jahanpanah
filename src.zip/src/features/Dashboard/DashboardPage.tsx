import React, { useState, useMemo, useEffect } from 'react';
// FIX: Replaced named imports from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { useLocation, useNavigate } = ReactRouterDOM;
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import {
  SupplyRequest,
  SupplyRequestData,
  CreateDraftData,
  PaginatedResponse,
} from '../../types';
import {
  workflowEngineApi,
  dashboardApi,
} from '../../services/api';
import SupplyRequestForm from './SupplyRequestForm';
import SupplyRequestsList from './SupplyRequestsList';
import RequestDetailsModal from './RequestDetailsModal';
import DashboardSummary from './DashboardSummary';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useServerStatus } from '../../context/ServerStatusContext';

const DashboardPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  const [formInitialData, setFormInitialData] = useState<Partial<SupplyRequest> | null>(null);
  const [viewingRequestId, setViewingRequestId] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const queryClient = useQueryClient();
  const { currentUser: loggedInUser } = useAuth();
  const { read: canRead, create: canCreate } = usePermissions('DASHBOARD');
  const toast = useToast();
  const { status: serverStatus } = useServerStatus();
  const isServerOffline = serverStatus === 'offline';
  
  const { data: summaryData, isLoading: isSummaryLoading, isError: isSummaryError } = useQuery({
      queryKey: ['dashboardSummary', loggedInUser?.id],
      queryFn: () => dashboardApi.getSummary({ userId: loggedInUser!.id }),
      enabled: !!loggedInUser && serverStatus === 'online',
      retry: false,
      refetchOnWindowFocus: false,
  });

  const { data: requestsResponse, isLoading: isRequestsLoading, isError: isRequestsError } = useQuery<PaginatedResponse<SupplyRequest>>({
      queryKey: ['dashboardRequests', loggedInUser?.id, page],
      queryFn: () => dashboardApi.getRequests({ userId: loggedInUser!.id }, page),
      enabled: !!loggedInUser && serverStatus === 'online',
      retry: false,
      refetchOnWindowFocus: false,
  });

  useEffect(() => {
    const prefilledData = location.state as CreateDraftData | undefined;
    if (prefilledData) {
      const initialFormData: Partial<SupplyRequest> = {
          requestTypeId: prefilledData.requestTypeId,
          imprestHolderId: prefilledData.imprestHolderId ? Number(prefilledData.imprestHolderId) : undefined,
          invoices: prefilledData.beneficiaryId ? [{ beneficiaryId: Number(prefilledData.beneficiaryId), items: [], invoiceNumber: '', attachmentName: '' }] : [],
      };
      setFormInitialData(initialFormData);
      navigate(location.pathname, { replace: true, state: null });
    }
    
    const requestIdFromNav = (location.state as any)?.viewRequestId;
    if (requestIdFromNav) {
        setViewingRequestId(requestIdFromNav);
        // Clear the state to prevent re-opening on re-renders/navigation
        navigate(location.pathname, { replace: true, state: null });
    }

  }, [location, navigate]);

  const createRequestMutation = useMutation({
    mutationFn: (newRequestData: SupplyRequestData) => workflowEngineApi.submitNewRequest(newRequestData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dashboardRequests'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardSummary'] });
      setFormInitialData(null);
      toast.success('درخواست شما با موفقیت ثبت و فرآیند آن آغاز شد!');
    },
    onError: (error: Error) => {
      toast.error(`خطا در ثبت درخواست: ${error.message}`);
    }
  });
  
  const resubmitMutation = useMutation({
    mutationFn: (data: { requestId: string, updatedData: SupplyRequestData }) => 
        workflowEngineApi.resubmitRejectedRequest(data.requestId, data.updatedData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dashboardRequests'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardSummary'] });
      setFormInitialData(null);
      toast.success('درخواست با موفقیت اصلاح و ارسال شد!');
    },
    onError: (error: Error) => {
      toast.error(`خطا در ارسال مجدد: ${error.message}`);
    }
  });

  // PERFORMANCE: Enrichment logic is removed. The backend now joins the necessary workflow
  // object directly onto the request object, simplifying client-side logic and improving performance.
  const requests = useMemo(() => {
    if (!loggedInUser || !requestsResponse?.data) return [];
    return requestsResponse.data
      .sort((a, b) => new Date(b.submissionDateForSort).getTime() - new Date(a.submissionDateForSort).getTime());
  }, [requestsResponse, loggedInUser]);

  const handlePendingClick = () => {
    if (!loggedInUser) return;
    navigate('/reports', { 
        state: { 
            filters: { 
                assigneeId: String(loggedInUser.id),
                status: 'IN_REVIEW' 
            } 
        } 
    });
  };

  const handleSubmissionsClick = () => {
      if (!loggedInUser) return;
      navigate('/reports', { 
          state: { 
              filters: { 
                  requesterId: String(loggedInUser.id) 
              } 
          } 
      });
  };

  if (!canRead) {
    return <AccessDenied />;
  }
  
  const isLoadingPageData = isSummaryLoading || isRequestsLoading;

  if (isLoadingPageData && serverStatus !== 'offline' && !isSummaryError && !isRequestsError) {
    return (
      <div className="flex justify-center items-center h-full p-10">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  
  if (!loggedInUser) {
    return <p>خطا: داده های اصلی برنامه بارگذاری نشد.</p>
  }

  if (formInitialData) {
    return (
      <SupplyRequestForm
        initialData={formInitialData as SupplyRequest}
        onSubmit={async (data) => {
            if (formInitialData && 'id' in formInitialData) { 
                resubmitMutation.mutate({ requestId: (formInitialData as SupplyRequest).id, updatedData: data });
            } else {
                createRequestMutation.mutate(data);
            }
        }}
        onCancel={() => {
            setFormInitialData(null);
        }}
        loggedInUserId={loggedInUser.id}
        isServerOffline={isServerOffline}
      />
    );
  }

  const handleAddNew = () => {
      setFormInitialData({}); 
  }
  
  const handleEditRequest = (request: SupplyRequest) => {
      setFormInitialData(request);
  }

  return (
    <div className="space-y-6">
      <DashboardSummary
        summary={summaryData}
        isLoading={isSummaryLoading}
        onPendingClick={handlePendingClick}
        onSubmissionsClick={handleSubmissionsClick}
        isError={isSummaryError}
      />
      <SupplyRequestsList
        supplyRequests={requests}
        onAddNew={handleAddNew}
        onViewDetails={(request) => setViewingRequestId(request.id)}
        onEditRequest={handleEditRequest}
        loggedInUserId={loggedInUser.id}
        canCreate={canCreate}
        pagination={{
            page: page,
            totalItems: requestsResponse?.total || 0,
            onPageChange: setPage,
        }}
        isServerOffline={isServerOffline}
        isError={isRequestsError}
      />
      {viewingRequestId && (
        <RequestDetailsModal
          requestId={viewingRequestId}
          onClose={() => setViewingRequestId(null)}
          onActionComplete={() => {
            setViewingRequestId(null);
            queryClient.invalidateQueries({ queryKey: ['dashboardRequests'] });
            queryClient.invalidateQueries({ queryKey: ['dashboardSummary'] });
          }}
          loggedInUserId={loggedInUser.id}
          isServerOffline={isServerOffline}
        />
      )}
    </div>
  );
};

export default DashboardPage;