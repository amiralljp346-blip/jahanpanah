import React, { useMemo, useEffect, useState, useRef } from 'react';
// FIX: Replaced named import from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { Link } = ReactRouterDOM;
import { useForm, useFieldArray, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { SupplyRequest, Person, RequestCategory, Unit, Workflow, SupplyRequestData, Attachment, Invoice, Contract, PETTY_CASH_ROLE_ID } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import { InvoiceCard } from './components/InvoiceCard';
import { useQuery } from '@tanstack/react-query';
import { contractsApi, requestCategoriesApi, workflowsApi, personsApi, unitsApi } from '../../services/api';
import { useDebounce } from '../../hooks/useDebounce';

interface SupplyRequestFormProps {
  initialData?: SupplyRequest | null;
  onSubmit: (data: SupplyRequestData) => void;
  onCancel: () => void;
  loggedInUserId: number;
  isServerOffline: boolean;
}

const fileToBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

// FIX: Removed the dynamic `availableBalance` from the schema creator to break the circular dependency.
const createSupplyRequestFormSchema = (requestCategories: RequestCategory[]) => {
    const baseSchema = z.object({
        requestTypeId: z.string().min(1, "انتخاب نوع درخواست الزامی است"),
        requesterId: z.number(),
        requestingUnitId: z.number(),
        amount: z.number().min(0, "مبلغ نمی‌تواند منفی باشد"),
        currency: z.enum(['RIAL', 'USD']),
        fundingSource: z.enum(['RESEARCH', 'PRODUCTION']),
        attachments: z.record(z.string(), z.object({ name: z.string(), url: z.string() }).optional()).optional(),
        invoices: z.array(z.object({
            id: z.number().optional(),
            invoiceNumber: z.string().optional(),
            beneficiaryId: z.string().min(1, "انتخاب ذی‌نفع الزامی است"),
            attachmentName: z.string().optional(),
            attachmentUrl: z.string().optional(),
            items: z.array(z.object({
                description: z.string().min(1, "شرح آیتم الزامی است"),
                quantity: z.number().min(0.01, "تعداد باید مثبت باشد"),
                unitPrice: z.number().min(0, "قیمت واحد نمی‌تواند منفی باشد"),
            })).min(1, "حداقل یک آیتم برای فاکتور ثبت کنید"),
        })).optional(),
        itemDescription: z.string().optional(),
        expenseType: z.enum(['CONSUMABLE', 'CAPITAL']).optional(),
        imprestHolderId: z.string().optional(),
        contractId: z.string().optional(),
        paymentTermDescription: z.string().optional(),
    });

    return baseSchema.superRefine((data, ctx) => {
        const selectedCategory = requestCategories.find(c => String(c.id) === data.requestTypeId);

        if (!selectedCategory) {
            return;
        }

        if (selectedCategory.key !== 'PETTY_CASH') {
            const requiredAttachments = Array.isArray(selectedCategory.attachments) ? selectedCategory.attachments : [];
            if (typeof data.attachments !== 'object' || data.attachments === null || Array.isArray(data.attachments)) {
                if (requiredAttachments.length > 0) {
                     ctx.addIssue({
                        code: z.ZodIssueCode.custom,
                        message: "فرمت داده‌های پیوست نامعتبر است.",
                        path: ['attachments'],
                    });
                }
            } else {
                for (const att of requiredAttachments) {
                    if (!data.attachments[att]?.url) {
                        ctx.addIssue({
                            code: z.ZodIssueCode.custom,
                            message: `پیوست "${att}" الزامی است.`,
                            path: ['attachments'],
                        });
                        break; 
                    }
                }
            }
        }


        switch (selectedCategory.key) {
            case 'DIRECT_PURCHASE':
                if (!data.expenseType) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['expenseType'], message: 'انتخاب نوع هزینه الزامی است.' });
                break;
            case 'PETTY_CASH':
                if (data.amount <= 0) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['amount'], message: 'مبلغ تنخواه باید مثبت باشد.' });
                // FIX: Dynamic balance validation removed from schema to prevent circular dependency.
                if (!data.expenseType) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['expenseType'], message: 'انتخاب نوع هزینه الزامی است.' });
                if (!data.imprestHolderId || data.imprestHolderId === "") ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['imprestHolderId'], message: 'انتخاب تنخواه بگیر الزامی است.' });
                break;
            case 'CONTRACT':
                if (!data.contractId) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['contractId'], message: 'انتخاب قرارداد الزامی است.' });
                if (!data.paymentTermDescription || data.paymentTermDescription === "") ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['paymentTermDescription'], message: 'انتخاب شرط پرداخت الزامی است.' });
                break;
        }
    });
};

type FormData = z.infer<ReturnType<typeof createSupplyRequestFormSchema>>;

const SupplyRequestForm: React.FC<SupplyRequestFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  loggedInUserId,
  isServerOffline,
}) => {
  // PERFORMANCE: Fetch all necessary data within the form component on-demand.
  const { data: requestCategories = [] } = useQuery<RequestCategory[]>({ queryKey: ['requestCategories_all'], queryFn: () => requestCategoriesApi.getAllUnpaginated() });
  const { data: workflows = [] } = useQuery<Workflow[]>({ queryKey: ['workflows_all'], queryFn: () => workflowsApi.getAllUnpaginated() });
  const { data: persons = [] } = useQuery<Person[]>({ queryKey: ['persons_all_form'], queryFn: () => personsApi.getAllUnpaginated() });
  
  // FIX: The form schema is now static and does not depend on component state.
  const formSchema = useMemo(() => createSupplyRequestFormSchema(requestCategories), [requestCategories]);

  const { register, handleSubmit, reset, control, setValue, watch, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
  });

  const selectedRequestTypeId = watch('requestTypeId');
  const selectedCategory = useMemo(() => requestCategories.find(c => String(c.id) === selectedRequestTypeId), [requestCategories, selectedRequestTypeId]);
  const watchedImprestHolderId = watch('imprestHolderId');

  const { data: pettyCashStatus, isLoading: isLoadingPettyCashStatus } = useQuery({
      queryKey: ['pettyCashStatus', watchedImprestHolderId],
      queryFn: () => personsApi.getPettyCashStatus(Number(watchedImprestHolderId)),
      enabled: !!watchedImprestHolderId && selectedCategory?.key === 'PETTY_CASH',
  });

  const { fields: invoiceFields, append: appendInvoice, remove: removeInvoice } = useFieldArray({
    control,
    name: 'invoices'
  });

  const watchedInvoices = watch('invoices');
  const currency = watch('currency', 'RIAL');
  
  const loggedInUser = useMemo(() => persons.find(p => p.id === loggedInUserId), [persons, loggedInUserId]);
  const beneficiaries = useMemo(() => persons.filter(p => p.isBeneficiary), [persons]);
  const imprestHolders = useMemo(() => persons.filter(p => p.roleIds?.includes(PETTY_CASH_ROLE_ID)), [persons]);

  const creatableCategories = useMemo(() => requestCategories.filter(cat => workflows.some(wf => wf.requestCategoryId === cat.id)), [requestCategories, workflows]);
  
  const [contractSearchText, setContractSearchText] = useState('');
  const [showContractOptions, setShowContractOptions] = useState(false);
  const contractInputRef = useRef<HTMLDivElement>(null);
  const debouncedContractSearch = useDebounce(contractSearchText, 300);

  const { data: contractOptions, isLoading: isLoadingContracts } = useQuery<Contract[]>({
      queryKey: ['contracts_for_request', debouncedContractSearch, loggedInUser?.unitId],
      queryFn: () => contractsApi.getAllUnpaginated({
          status: 'ACTIVE',
          q: debouncedContractSearch,
          unitId: loggedInUser?.unitId,
      }),
      enabled: selectedCategory?.key === 'CONTRACT',
  });
  
  const watchedContractId = watch('contractId');
  const selectedContract = useMemo(() => contractOptions?.find(c => String(c.id) === watchedContractId), [contractOptions, watchedContractId]);
  const availablePaymentTerms = useMemo(() => selectedContract?.paymentTerms.filter(pt => pt.status === 'PENDING') || [], [selectedContract]);
  const watchedPaymentTermDesc = watch('paymentTermDescription');

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (contractInputRef.current && !contractInputRef.current.contains(event.target as Node)) {
            setShowContractOptions(false);
        }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [contractInputRef]);


  useEffect(() => {
    if (selectedContract && watchedPaymentTermDesc) {
        const term = selectedContract.paymentTerms.find(pt => pt.description === watchedPaymentTermDesc);
        if (term) {
            setValue('amount', term.amount, { shouldValidate: true });
        }
    }
    if (selectedCategory?.key === 'CONTRACT' && !watchedPaymentTermDesc) {
        setValue('paymentTermDescription', '');
    }
  }, [watchedContractId, selectedContract, watchedPaymentTermDesc, setValue, selectedCategory]);


  useEffect(() => {
    if (!loggedInUser) return;

    const defaultValues: Partial<FormData> = {
        requestTypeId: initialData?.requestTypeId ? String(initialData.requestTypeId) : '',
        requesterId: initialData?.requesterId || loggedInUserId,
        requestingUnitId: initialData?.requestingUnitId || loggedInUser.unitId || 0,
        itemDescription: initialData?.itemDescription || '',
        amount: Number(initialData?.amount) || 0,
        currency: initialData?.currency || 'RIAL',
        fundingSource: initialData?.fundingSource || 'PRODUCTION',
        expenseType: initialData?.expenseType,
        imprestHolderId: initialData?.imprestHolderId ? String(initialData.imprestHolderId) : '',
        attachments: (initialData?.attachments as Record<string, Attachment>) || {},
        invoices: initialData?.invoices?.map(inv => ({
            ...inv,
            beneficiaryId: inv.beneficiaryId ? String(inv.beneficiaryId) : '',
            items: inv.items?.map(i => ({...i, quantity: i.quantity || 1, unitPrice: i.unitPrice || 0})) || []
        })) || [],
        contractId: initialData?.contractId ? String(initialData.contractId) : '',
        paymentTermDescription: initialData?.paymentTermDescription || '',
    };
    reset(defaultValues as any);
    
    if(initialData?.contractId) {
        contractsApi.getAllUnpaginated({ id: initialData.contractId }).then(contracts => {
            if (contracts[0]) setContractSearchText(contracts[0].contractTitle);
        });
    }

  }, [initialData, loggedInUser, persons, reset]);

  useEffect(() => {
    const total = watchedInvoices?.reduce((sum, invoice) => {
        const invoiceTotal = invoice.items?.reduce((invoiceSum, item) => invoiceSum + ((item.quantity || 0) * (item.unitPrice || 0)), 0) || 0;
        return sum + invoiceTotal;
    }, 0) || 0;
    if (total > 0 || invoiceFields.length > 0) {
        setValue('amount', total, { shouldValidate: true });
    }
  }, [watchedInvoices, setValue, invoiceFields.length]);

  const handleAttachmentChange = async (e: React.ChangeEvent<HTMLInputElement>, attachmentKey: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64Url = await fileToBase64(file);
      setValue(`attachments.${attachmentKey}`, { name: file.name, url: base64Url }, { shouldValidate: true, shouldDirty: true });
    }
  };

  const submitHandler: SubmitHandler<FormData> = (data) => {
    const selectedCategory = requestCategories.find(c => String(c.id) === data.requestTypeId);
    let dueDate: string | undefined = undefined;

    if (selectedCategory?.deadlineDays && selectedCategory.deadlineDays > 0) {
        const submissionDateObj = new Date();
        const dueDateObj = new Date(submissionDateObj);
        dueDateObj.setDate(submissionDateObj.getDate() + selectedCategory.deadlineDays);
        dueDate = dueDateObj.toISOString();
    }
    
    const baseData: Partial<SupplyRequestData> = {
        requestTypeId: Number(data.requestTypeId),
        requesterId: data.requesterId,
        requestingUnitId: data.requestingUnitId,
        amount: data.amount,
        currency: data.currency,
        fundingSource: data.fundingSource,
        attachments: (data.attachments as Record<string, Attachment>) ?? {},
        submissionDate: new Date().toLocaleDateString('fa-IR'),
        submissionDateForSort: new Date().toISOString(),
        dueDate,
    };
    
    let specificData: Partial<SupplyRequestData> = {};

    switch (selectedCategory?.key) {
        case 'DIRECT_PURCHASE':
            specificData = {
                itemDescription: data.itemDescription,
                expenseType: data.expenseType,
                invoices: data.invoices?.map(inv => ({
                    ...inv,
                    beneficiaryId: Number(inv.beneficiaryId),
                })) as Invoice[] ?? [],
            };
            break;
        case 'PETTY_CASH':
            specificData = {
                itemDescription: data.itemDescription,
                expenseType: data.expenseType,
                imprestHolderId: data.imprestHolderId ? Number(data.imprestHolderId) : undefined,
                 // Send empty arrays/objects for petty cash as they are not used
                invoices: [],
                attachments: {},
            };
            break;
        case 'CONTRACT':
            specificData = {
                contractId: data.contractId ? Number(data.contractId) : undefined,
                paymentTermDescription: data.paymentTermDescription,
            };
            break;
        default:
             specificData = {
                itemDescription: data.itemDescription,
                invoices: data.invoices?.map(inv => ({
                    ...inv,
                    beneficiaryId: Number(inv.beneficiaryId),
                })) as Invoice[] ?? [],
             };
    }

    const finalData = { ...baseData, ...specificData } as SupplyRequestData;

    onSubmit(finalData);
  };

  const totalAmount = watch('amount');
  const isEditing = !!(initialData && 'id' in initialData && initialData.id);

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-gray-800 mb-6 border-b pb-4">
        {isEditing ? 'ویرایش و ارسال مجدد درخواست' : 'ثبت درخواست جدید'}
      </h2>
      <form onSubmit={handleSubmit(submitHandler)} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div><label className="block text-sm font-medium text-gray-700 mb-1">نوع درخواست</label><select {...register('requestTypeId')} disabled={isEditing} className="w-full border p-2 rounded bg-white disabled:bg-gray-100"><option value="">...</option>{(isEditing ? requestCategories : creatableCategories).map(c => <option key={c.id} value={c.id}>{c.label}</option>)}</select>{errors.requestTypeId && <p className="text-red-500 text-xs mt-1">{String(errors.requestTypeId.message)}</p>}</div>
          <div><label className="block text-sm font-medium text-gray-700 mb-1">منبع اعتبار</label><select {...register('fundingSource')} className="w-full border p-2 rounded bg-white"><option value="PRODUCTION">تولیدی</option><option value="RESEARCH">تحقیقاتی</option></select></div>
        </div>

        {selectedCategory && (
            <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
                    <div><label className="block text-sm font-medium text-gray-700 mb-1">ارز</label><select {...register('currency')} className="w-full border p-2 rounded bg-white"><option value="RIAL">ریال</option><option value="USD">دلار</option></select></div>
                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">مبلغ کل</label>
                        {/* FIX: Moved dynamic validation from the schema to the field registration to break the circular dependency. */}
                        <input type="number" {...register('amount', { 
                            valueAsNumber: true,
                            validate: value => {
                                if (selectedCategory?.key === 'PETTY_CASH' && pettyCashStatus) {
                                    if (value > pettyCashStatus.availableBalance) {
                                        return `مبلغ درخواستی از اعتبار باقی‌مانده (${formatCurrency(pettyCashStatus.availableBalance, 'RIAL')}) بیشتر است.`;
                                    }
                                }
                                return true;
                            }
                        })} 
                        className="w-full border p-2 rounded bg-gray-50" readOnly={invoiceFields.length > 0 || selectedCategory.key === 'CONTRACT'} />
                        {errors.amount && <p className="text-red-500 text-xs mt-1">{String(errors.amount.message)}</p>}
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {selectedCategory.key === 'DIRECT_PURCHASE' && (
                        <div className="md:col-span-3"><label className="block text-sm font-medium text-gray-700 mb-1">توضیحات</label><textarea {...register('itemDescription')} rows={2} className="w-full border p-2 rounded" />{errors.itemDescription && <p className="text-red-500 text-xs mt-1">{String(errors.itemDescription.message)}</p>}</div>
                    )}
                    
                    {(selectedCategory.key === 'DIRECT_PURCHASE' || selectedCategory.key === 'PETTY_CASH') && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">نوع هزینه</label>
                            <select {...register('expenseType')} className="w-full border p-2 rounded bg-white">
                                <option value="">...</option>
                                <option value="CONSUMABLE">مصرفی</option>
                                <option value="CAPITAL">سرمایه‌ای</option>
                            </select>
                             {errors.expenseType && <p className="text-red-500 text-xs mt-1">{String(errors.expenseType.message)}</p>}
                        </div>
                    )}

                    {selectedCategory.key === 'PETTY_CASH' && (
                         <>
                            <div className="md:col-span-2">
                                <label className="block text-sm font-medium text-gray-700 mb-1">تنخواه بگیر</label>
                                <select {...register('imprestHolderId')} className="w-full border p-2 rounded bg-white">
                                    <option value="">...</option>
                                    {imprestHolders.map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}
                                </select>
                                {errors.imprestHolderId && <p className="text-red-500 text-xs mt-1">{String(errors.imprestHolderId.message)}</p>}
                            </div>
                            <div className="md:col-span-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                {isLoadingPettyCashStatus ? <p className="text-sm text-gray-600">در حال دریافت اطلاعات اعتبار...</p> : pettyCashStatus ? (
                                    <div className="grid grid-cols-3 gap-4 text-center">
                                        <div><p className="text-xs text-gray-500">سقف اعتبار</p><p className="font-bold text-lg">{formatCurrency(pettyCashStatus.limit, 'RIAL')}</p></div>
                                        <div><p className="text-xs text-gray-500">تنخواه در جریان</p><p className="font-bold text-lg text-yellow-600">{formatCurrency(pettyCashStatus.outstandingAmount, 'RIAL')}</p></div>
                                        <div><p className="text-xs text-gray-500">مبلغ مجاز</p><p className="font-bold text-lg text-green-600">{formatCurrency(pettyCashStatus.availableBalance, 'RIAL')}</p></div>
                                    </div>
                                ) : <p className="text-sm text-gray-600">ابتدا یک تنخواه بگیر انتخاب کنید تا اطلاعات اعتبار نمایش داده شود.</p>}
                            </div>
                        </>
                    )}

                    {selectedCategory.key === 'CONTRACT' && (
                        <div className="md:col-span-3">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="relative" ref={contractInputRef}>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">جستجو و انتخاب قرارداد</label>
                                    <input
                                        type="text"
                                        value={contractSearchText}
                                        onChange={(e) => {
                                            setContractSearchText(e.target.value);
                                            if (watch('contractId')) setValue('contractId', '');
                                        }}
                                        onFocus={() => setShowContractOptions(true)}
                                        placeholder="شماره یا عنوان قرارداد را جستجو کنید..."
                                        className="w-full border p-2 rounded bg-white"
                                        autoComplete="off"
                                    />
                                    {errors.contractId && <p className="text-red-500 text-xs mt-1">{String(errors.contractId.message)}</p>}
                                    {showContractOptions && (
                                        <div className="absolute top-full left-0 right-0 bg-white border rounded-b-lg shadow-lg z-10 max-h-60 overflow-y-auto">
                                            {isLoadingContracts ? (
                                                <div className="p-3 text-xs text-gray-500">در حال جستجو...</div>
                                            ) : (contractOptions || []).length === 0 ? (
                                                <div className="p-3 text-xs text-gray-500">
                                                    هیچ قرارداد فعالی یافت نشد. <Link to="/contracts" className="text-blue-600 hover:underline">ایجاد قرارداد جدید</Link>
                                                </div>
                                            ) : (
                                                (contractOptions || []).map(c => (
                                                    <button
                                                        type="button"
                                                        key={c.id}
                                                        onClick={() => {
                                                            setValue('contractId', String(c.id), { shouldValidate: true });
                                                            setContractSearchText(c.contractTitle);
                                                            setShowContractOptions(false);
                                                        }}
                                                        className="w-full text-right p-3 text-sm hover:bg-blue-50"
                                                    >
                                                        <span className="font-bold">{c.contractNumber}</span> - {c.contractTitle}
                                                    </button>
                                                ))
                                            )}
                                        </div>
                                    )}
                                </div>
                                <div>
                                   <label className="block text-sm font-medium text-gray-700 mb-1">انتخاب شرط پرداخت</label>
                                    <select {...register('paymentTermDescription')} disabled={!selectedContract} className="w-full border p-2 rounded bg-white disabled:bg-gray-100">
                                        <option value="">...</option>
                                        {availablePaymentTerms.map(pt => <option key={pt.id} value={pt.description}>{pt.description} ({formatCurrency(pt.amount, 'RIAL')})</option>)}
                                    </select>
                                    {errors.paymentTermDescription && <p className="text-red-500 text-xs mt-1">{String(errors.paymentTermDescription.message)}</p>}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        )}

        {selectedCategory && !['PETTY_CASH', 'CONTRACT'].includes(selectedCategory.key) &&
          <div className="space-y-4 pt-4 border-t">
              <h3 className="font-semibold text-lg text-gray-700">فاکتورها</h3>
              <div className="space-y-4">
                  {invoiceFields.map((field, index) => <InvoiceCard key={field.id} index={index} control={control} register={register} setValue={setValue} removeInvoice={removeInvoice} beneficiaries={beneficiaries} currency={currency} errors={errors} /> )}
              </div>
              <button type="button" onClick={() => appendInvoice({ beneficiaryId: '', items: [{ description: '', quantity: 1, unitPrice: 0 }] })} className="text-sm text-blue-600 font-semibold hover:underline">+ افزودن فاکتور</button>
          </div>
        }
        
        { selectedCategory && selectedCategory.key !== 'PETTY_CASH' && Array.isArray(selectedCategory.attachments) && selectedCategory.attachments.length > 0 &&
            <div className="space-y-4 pt-4 border-t">
                <h3 className="font-semibold text-lg text-gray-700">پیوست‌های الزامی</h3>
                {errors.attachments && <p className="text-red-500 text-xs my-2 p-2 bg-red-50 rounded-md">{String(errors.attachments.message)}</p>}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {selectedCategory.attachments.map(att => (
                        <div key={att}><label className="block text-sm font-medium text-gray-700 mb-1">{att}</label><input type="file" onChange={(e) => handleAttachmentChange(e, att)} className="w-full text-xs text-gray-500 file:mr-4 file:py-1 file:px-2 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-violet-50 file:text-violet-700 hover:file:bg-violet-100" /></div>
                    ))}
                </div>
            </div>
        }
        
        <div className="flex justify-between items-center pt-6 border-t">
          <div className="text-lg font-bold text-gray-800">مبلغ نهایی: <span className="font-mono text-blue-600">{formatCurrency(totalAmount, currency)}</span></div>
          <div className="flex gap-2">
            <button type="button" onClick={onCancel} className="bg-gray-200 text-gray-800 px-6 py-2 rounded-lg font-semibold hover:bg-gray-300">انصراف</button>
            <div className="relative group">
                <button 
                    type="submit" 
                    disabled={isServerOffline}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {isEditing ? 'ارسال مجدد' : 'ثبت و شروع فرآیند'}
                </button>
                 {isServerOffline && (
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max hidden group-hover:block bg-gray-800 text-white text-xs rounded-lg py-1 px-3 z-50">
                        سرور در دسترس نیست.
                    </div>
                )}
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default SupplyRequestForm;