import React from 'react';

// This page has been deprecated and its functionality merged into the PersonsPage.
// To manage beneficiaries, please use the "Persons and Beneficiaries Management" page.
const BeneficiariesPage: React.FC = () => null;
export default BeneficiariesPage;