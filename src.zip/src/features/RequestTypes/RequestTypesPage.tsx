
import React, { useState, useEffect } from 'react';
import { useForm, useFieldArray, SubmitHandler, Resolver } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { RequestCategory, RequestCategoryData } from '../../types';
import { requestCategoriesApi } from '../../services/api';
import Modal from '../../components/Modal';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { useServerStatus } from '../../context/ServerStatusContext';

const RequestCategoryFormSchema = z.object({
  id: z.number(),
  key: z.string(),
  label: z.string().min(2, "عنوان الزامی است"),
  deadlineDays: z.preprocess(
    (val) => (val === "" || val == null ? undefined : Number(val)),
    z.number().int().min(0, "مهلت انجام نمی‌تواند منفی باشد.").optional()
  ),
  attachments: z.array(z.object({ value: z.string().min(1, "نام پیوست الزامی است") })),
  subtypes: z.array(z.object({ id: z.number(), label: z.string().min(1, "عنوان زیرشاخه الزامی است") })).optional(),
}).superRefine((data, ctx) => {
    if (data.id === 0) { 
        if (!data.key || data.key.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "کلید سیستمی الزامی است.", path: ["key"] });
        } else if (!/^[A-Z0-9_]+$/.test(data.key)) {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "کلید سیستمی فقط میتواند شامل حروف بزرگ انگلیسی، عدد و خط زیر باشد.", path: ["key"] });
        }
    }
});

type FormData = {
  id: number;
  key: string;
  label: string;
  deadlineDays?: number;
  attachments: { value: string; }[];
  subtypes?: { id: number; label: string; }[];
};

const persianToEnglishKey = (str: string): string => {
    if (!str) return '';
    const persianMap: { [key: string]: string } = {
        'ا': 'A', 'آ': 'A', 'ب': 'B', 'پ': 'P', 'ت': 'T', 'ث': 'S', 'ج': 'J', 'چ': 'CH',
        'ح': 'H', 'خ': 'KH', 'د': 'D', 'ذ': 'Z', 'ر': 'R', 'ز': 'Z', 'ژ': 'ZH', 'س': 'S',
        'ش': 'SH', 'ص': 'S', 'ض': 'Z', 'ط': 'T', 'ظ': 'Z', 'ع': 'A', 'غ': 'GH', 'ف': 'F',
        'ق': 'GH', 'ک': 'K', 'گ': 'G', 'ل': 'L', 'م': 'M', 'ن': 'N', 'و': 'V', 'ه': 'H',
        'ی': 'Y', ' ': '_', 'ء': 'A', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5',
        '۶': '6', '۷': '7', '۸': '8', '۹': '9', '۰': '0'
    };
    return str.split('').map(char => persianMap[char] || char)
        .join('').toUpperCase().replace(/[^A-Z0-9_]/g, '').replace(/__+/g, '_');
};


const RequestTypesPage: React.FC = () => {
  const { read: canRead, create: canCreate, update: canUpdate } = usePermissions('REQUEST_TYPES');
  const queryClient = useQueryClient();
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedSearch = useDebounce(searchQuery, 300);
  const { status: serverStatus } = useServerStatus();

  const { data: categoriesResponse, isLoading } = useQuery({
      queryKey: ['requestCategories', page, debouncedSearch],
      queryFn: () => requestCategoriesApi.getAll(page, debouncedSearch),
      placeholderData: (previousData) => previousData,
      enabled: serverStatus === 'online',
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<RequestCategory | null>(null);

  const { register, handleSubmit, reset, control, watch, setValue, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(RequestCategoryFormSchema) as unknown as Resolver<FormData>
  });

  const { fields: attachmentFields, append: appendAttachment, remove: removeAttachment } = useFieldArray({ control, name: "attachments" });
  const { fields: subtypeFields, append: appendSubtype, remove: removeSubtype } = useFieldArray({ control, name: "subtypes" });
  
  const watchedLabel = watch('label');

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch]);
  
  useEffect(() => {
    if (!editingCategory) { 
      const generatedKey = persianToEnglishKey(watchedLabel);
      setValue('key', generatedKey, { shouldValidate: true });
    }
  }, [watchedLabel, editingCategory, setValue]);


  useEffect(() => {
    if (isModalOpen) {
      if (editingCategory) {
        reset({
          id: editingCategory.id,
          key: editingCategory.key,
          label: editingCategory.label,
          deadlineDays: editingCategory.deadlineDays || undefined,
          attachments: Array.isArray(editingCategory.attachments) ? editingCategory.attachments.map(att => ({ value: att })) : [],
          subtypes: editingCategory.subtypes || [],
        });
      } else {
        reset({ id: 0, key: '', label: '', attachments: [], subtypes: [], deadlineDays: undefined });
      }
    }
  }, [isModalOpen, editingCategory, reset]);


  const mutation = useMutation({
    mutationFn: (data: FormData) => {
      const { id, ...formData } = data;
      const categoryData: RequestCategoryData = {
        key: formData.key,
        label: formData.label,
        attachments: formData.attachments.map(att => att.value),
        subtypes: formData.subtypes,
        deadlineDays: formData.deadlineDays,
      };

      if (id && id !== 0) {
        return requestCategoriesApi.update(id, categoryData);
      }
      return requestCategoriesApi.create(categoryData);
    },
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ['requestCategories'] }); 
      handleCloseModal();
      toast.success('نوع درخواست با موفقیت ذخیره شد.');
    },
    onError: (error: Error) => toast.error(`ذخیره تغییرات با خطا مواجه شد: ${error.message}`)
  });

  const handleOpenModal = (category: RequestCategory | null = null) => {
    setEditingCategory(category);
    setIsModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingCategory(null);
  };
  
  const onSubmit: SubmitHandler<FormData> = (data) => mutation.mutate(data);

  const columns: ColumnDef<RequestCategory>[] = [
    { accessorKey: 'label', header: 'عنوان درخواست' },
    { accessorKey: 'deadlineDays', header: 'مهلت انجام', cell: (cat) => cat.deadlineDays ? `${cat.deadlineDays} روز` : '---' },
    { accessorKey: 'attachments', header: 'پیوست‌های الزامی', cell: (cat) => <div className="flex flex-wrap gap-1">{(Array.isArray(cat.attachments) ? cat.attachments : []).map((att, i) => <span key={i} className="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded-full">{att}</span>)}</div> },
    { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (category) => <div className="flex justify-center"><button onClick={() => handleOpenModal(category)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">ویرایش</button></div> }
  ];

  if (!canRead) return <AccessDenied />;

  return (
    <section className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">مدیریت انواع درخواست</h2>
        {canCreate && (
          <button onClick={() => handleOpenModal()} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-blue-700 shadow-md flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110 2h3V6a1 1 0 011-1z" />
            </svg>
            افزودن نوع جدید
          </button>
        )}
      </div>

       <div className="relative">
          <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو بر اساس عنوان یا کلید سیستمی..."
              className="w-full p-2 pl-10 border rounded-md"
          />
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
      </div>

      {isLoading && serverStatus !== 'offline' ? <p>در حال بارگذاری...</p> :
        <DataTable
          columns={columns}
          data={categoriesResponse?.data || []}
          pagination={{ page, total: categoriesResponse?.total || 0, itemsPerPage: 20 }}
          onPageChange={setPage}
        />
      }

      {isModalOpen && (
        <Modal title={editingCategory ? 'ویرایش نوع درخواست' : 'افزودن نوع درخواست جدید'} onClose={handleCloseModal} size="3xl">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="p-6 max-h-[70vh] overflow-y-auto space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">عنوان درخواست</label>
                  <input {...register('label')} className="w-full border p-2 rounded" />
                  {errors.label && <p className="text-red-500 text-xs mt-1">{errors.label.message as string}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">مهلت انجام (روز)</label>
                  <input type="number" {...register('deadlineDays')} className="w-full border p-2 rounded" min="0" />
                  {errors.deadlineDays && <p className="text-red-500 text-xs mt-1">{errors.deadlineDays.message as string}</p>}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">کلید سیستمی (غیرقابل ویرایش)</label>
                <input {...register('key')} readOnly className="w-full border p-2 rounded bg-gray-100 font-mono" />
                {errors.key && <p className="text-red-500 text-xs mt-1">{errors.key.message as string}</p>}
              </div>

              <div className="pt-4 border-t">
                <h3 className="font-semibold text-gray-700 mb-2">پیوست‌های الزامی</h3>
                {attachmentFields.map((field, index) => (
                  <div key={field.id} className="flex items-center gap-2 mb-2">
                    <input {...register(`attachments.${index}.value`)} placeholder="نام پیوست" className="w-full border p-2 rounded" />
                    <button type="button" onClick={() => removeAttachment(index)} className="bg-red-100 text-red-700 h-9 w-9 flex items-center justify-center rounded-md hover:bg-red-200 font-bold text-xl">&times;</button>
                  </div>
                ))}
                <button type="button" onClick={() => appendAttachment({ value: '' })} className="text-sm text-blue-600 font-semibold hover:underline">+ افزودن پیوست</button>
                {errors.attachments && <p className="text-red-500 text-xs mt-1">{errors.attachments.root?.message as string}</p>}
              </div>

              <div className="pt-4 border-t">
                <h3 className="font-semibold text-gray-700 mb-2">زیرشاخه‌های نوع پرداخت (برای قرارداد)</h3>
                {subtypeFields.map((field, index) => (
                  <div key={field.id} className="flex items-center gap-2 mb-2">
                    <input {...register(`subtypes.${index}.label`)} placeholder="عنوان زیرشاخه" className="w-full border p-2 rounded" />
                    <button type="button" onClick={() => removeSubtype(index)} className="bg-red-100 text-red-700 h-9 w-9 flex items-center justify-center rounded-md hover:bg-red-200 font-bold text-xl">&times;</button>
                  </div>
                ))}
                <button type="button" onClick={() => appendSubtype({ id: Date.now(), label: '' })} className="text-sm text-blue-600 font-semibold hover:underline">+ افزودن زیرشاخه</button>
              </div>
            </div>

            <div className="flex justify-end gap-2 p-4 border-t bg-gray-50">
              <button type="button" onClick={handleCloseModal} className="bg-gray-200 text-gray-800 px-4 py-2 rounded font-semibold">لغو</button>
              <button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">
                {mutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </section>
  );
};

export default RequestTypesPage;