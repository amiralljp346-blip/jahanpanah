
import React, { useState, useEffect, useMemo } from 'react';
import { useForm, SubmitHandler, Resolver } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { z } from 'zod';

// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Person, PersonData, PersonSchema, BeneficiarySchema, PaginatedResponse } from '../../types';
import { personsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { DataTable, ColumnDef } from '../../components/DataTable';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { useAuth } from '../../hooks/useAuth';
import { useServerStatus } from '../../context/ServerStatusContext';
import { useMainLayoutContext } from '../../context/MainLayoutContext';

type PersonFormData = z.infer<typeof PersonSchema>;
type BeneficiaryFormData = z.infer<typeof BeneficiarySchema>;

const PersonsPage: React.FC = () => {
    const queryClient = useQueryClient();
    const { currentUser } = useAuth();
    const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('PERSONS');
    const toast = useToast();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const { status: serverStatus } = useServerStatus();
    const { units } = useMainLayoutContext();
    const [activeTab, setActiveTab] = useState<'persons' | 'beneficiaries'>('persons');

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingPerson, setEditingPerson] = useState<Person | null>(null);

    const { data: personsResponse, isLoading: isPersonsLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['persons', activeTab, page, debouncedSearch],
        queryFn: () => personsApi.getAll(page, debouncedSearch, { isBeneficiary: String(activeTab === 'beneficiaries') }),
        placeholderData: (previousData) => previousData,
        enabled: serverStatus === 'online',
    });

    const personForm = useForm<PersonFormData>({ resolver: zodResolver(PersonSchema) as unknown as Resolver<PersonFormData> });
    const beneficiaryForm = useForm<BeneficiaryFormData>({ resolver: zodResolver(BeneficiarySchema) });

    useEffect(() => {
        setPage(1);
    }, [debouncedSearch, activeTab]);
    
    useEffect(() => {
        if (isModalOpen) {
            if (editingPerson) {
                if (editingPerson.isBeneficiary) {
                    beneficiaryForm.reset(editingPerson);
                } else {
                    personForm.reset({ ...editingPerson, unitId: editingPerson.unitId || undefined });
                }
            } else {
                personForm.reset({ firstName: '', lastName: '', nationalId: '', personnelCode: '', unitId: undefined, accountNumber: '', cardNumber: '', iban: '', pettyCashLimit: undefined });
                beneficiaryForm.reset({ personType: 'NATURAL', firstName: '', lastName: '', nationalId: '', accountNumber: '', iban: '' });
            }
        }
    }, [editingPerson, isModalOpen, personForm.reset, beneficiaryForm.reset]);
    
    const mutation = useMutation({
        // FIX: The type for `formData` was too restrictive. It is updated to include `actingUserId`
        // to match the data passed in `mutation.mutate`. The incorrect `as PersonData` cast is also removed.
        mutationFn: (data: { formData: Partial<PersonData> & { actingUserId?: number }, id?: number }) => {
            const { id, formData } = data;
            return id ? personsApi.update(id, formData) : personsApi.create(formData);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            queryClient.invalidateQueries({ queryKey: ['units_tree'] });
            setIsModalOpen(false);
            toast.success('عملیات با موفقیت انجام شد.');
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const deleteMutation = useMutation({
        mutationFn: (id: number) => personsApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            toast.success('مورد با موفقیت حذف شد.');
        },
        onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`),
    });

    const onPersonSubmit: SubmitHandler<PersonFormData> = (data) => {
        const fullName = `${data.firstName} ${data.lastName}`.trim();
        mutation.mutate({ formData: { ...data, fullName, isBeneficiary: false, actingUserId: currentUser!.id }, id: editingPerson?.id });
    };

    const onBeneficiarySubmit: SubmitHandler<BeneficiaryFormData> = (data) => {
        const fullName = `${data.firstName} ${data.lastName}`.trim();
        mutation.mutate({ formData: { ...data, fullName, isBeneficiary: true, actingUserId: currentUser!.id }, id: editingPerson?.id });
    };

    const handleDelete = (person: Person) => {
        const typeText = person.isBeneficiary ? 'این ذی‌نفع' : 'این شخص';
        if (window.confirm(`آیا از حذف ${typeText} مطمئن هستید؟ این عمل غیرقابل بازگشت است.`)) {
            deleteMutation.mutate(person.id);
        }
    };
    
    const openModal = (person: Person | null = null) => {
        setEditingPerson(person);
        setIsModalOpen(true);
    };

    const personColumns: ColumnDef<Person>[] = [
        { accessorKey: 'fullName', header: 'نام کامل' },
        { accessorKey: 'nationalId', header: 'کد ملی' },
        { accessorKey: 'unitName', header: 'واحد / سمت' },
        { accessorKey: 'isSystemUser', header: 'ویژگی‌ها', cell: (p) => <div className="flex flex-col gap-1.5 text-xs">{p.isSystemUser && <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full w-fit">کاربر سامانه</span>}{!!p.pettyCashLimit && p.pettyCashLimit > 0 && <span className="bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded-full w-fit">تنخواه بگیر</span>}</div>},
        { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (person) => <div className="flex justify-center gap-4"><button onClick={() => openModal(person)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">ویرایش</button><button onClick={() => handleDelete(person)} disabled={!canDelete || person.isSystemUser} className="text-red-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline" title={person.isSystemUser ? "امکان حذف کاربری که به سیستم دسترسی دارد وجود ندارد." : ""}>حذف</button></div>}
    ];

    const beneficiaryColumns: ColumnDef<Person>[] = [
        { accessorKey: 'fullName', header: 'نام کامل' },
        { accessorKey: 'personType', header: 'نوع', cell: p => p.personType === 'LEGAL' ? 'حقوقی' : 'حقیقی' },
        { accessorKey: 'nationalId', header: 'کد / شناسه ملی' },
        { accessorKey: 'accountNumber', header: 'شماره حساب' },
        { accessorKey: 'iban', header: 'شماره شبا' },
        { accessorKey: 'actions', header: 'عملیات', width: '120px', cell: (person) => <div className="flex justify-center gap-4"><button onClick={() => openModal(person)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">ویرایش</button><button onClick={() => handleDelete(person)} disabled={!canDelete} className="text-red-600 hover:underline font-semibold disabled:text-gray-400 disabled:no-underline">حذف</button></div>}
    ];

    if (!canRead) return <AccessDenied />;

    const isBeneficiaryForm = (editingPerson && editingPerson.isBeneficiary) || (!editingPerson && activeTab === 'beneficiaries');

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">مدیریت اشخاص و ذی‌نفعان</h2>
                <button onClick={() => openModal()} disabled={!canCreate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-blue-700 disabled:bg-gray-400">
                    افزودن {activeTab === 'persons' ? 'شخص' : 'ذی‌نفع'} جدید
                </button>
            </div>
            
            <div className="border-b border-gray-200">
                <nav className="flex -mb-px gap-6">
                    <button onClick={() => setActiveTab('persons')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'persons' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>اشخاص داخلی</button>
                    <button onClick={() => setActiveTab('beneficiaries')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'beneficiaries' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>ذی‌نفعان</button>
                </nav>
            </div>

            <div className="relative">
                <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="جستجو بر اساس نام، کد ملی و..." className="w-full p-2 pl-10 border rounded-md" />
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>

            {isPersonsLoading && serverStatus !== 'offline' ? <p>در حال بارگذاری...</p> : 
                <DataTable 
                    columns={activeTab === 'persons' ? personColumns : beneficiaryColumns}
                    data={personsResponse?.data || []}
                    pagination={{ page, total: personsResponse?.total || 0, itemsPerPage: 20 }}
                    onPageChange={setPage}
                />
            }

            {isModalOpen && (
                <Modal title={editingPerson ? `ویرایش: ${editingPerson.fullName}` : `افزودن ${activeTab === 'persons' ? 'شخص' : 'ذی‌نفع'} جدید`} onClose={() => setIsModalOpen(false)} size="3xl">
                    {isBeneficiaryForm ? (
                        <form onSubmit={beneficiaryForm.handleSubmit(onBeneficiarySubmit)}>
                            <div className="p-6 max-h-[80vh] overflow-y-auto space-y-4">
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">نوع شخص</label><select {...beneficiaryForm.register('personType')} className="w-full border p-2 rounded-md bg-white"><option value="NATURAL">حقیقی</option><option value="LEGAL">حقوقی</option></select></div>
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">کد / شناسه ملی</label><input {...beneficiaryForm.register('nationalId')} className="w-full border p-2 rounded-md" />{beneficiaryForm.formState.errors.nationalId && <p className="text-red-500 text-xs mt-1">{String(beneficiaryForm.formState.errors.nationalId.message)}</p>}</div>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">نام</label><input {...beneficiaryForm.register('firstName')} className="w-full border p-2 rounded-md" />{beneficiaryForm.formState.errors.firstName && <p className="text-red-500 text-xs mt-1">{String(beneficiaryForm.formState.errors.firstName.message)}</p>}</div>
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">نام خانوادگی/شرکت</label><input {...beneficiaryForm.register('lastName')} className="w-full border p-2 rounded-md" />{beneficiaryForm.formState.errors.lastName && <p className="text-red-500 text-xs mt-1">{String(beneficiaryForm.formState.errors.lastName.message)}</p>}</div>
                                </div>
                                <div className="pt-4 border-t"><h3 className="text-md font-semibold text-gray-800 mb-2">اطلاعات مالی (اجباری)</h3>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره حساب</label><input {...beneficiaryForm.register('accountNumber')} className="w-full border p-2 rounded-md" />{beneficiaryForm.formState.errors.accountNumber && <p className="text-red-500 text-xs mt-1">{String(beneficiaryForm.formState.errors.accountNumber.message)}</p>}</div>
                                        <div className="sm:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">شماره شبا (IBAN)</label><input {...beneficiaryForm.register('iban')} className="w-full border p-2 rounded-md" dir="ltr" />{beneficiaryForm.formState.errors.iban && <p className="text-red-500 text-xs mt-1">{String(beneficiaryForm.formState.errors.iban.message)}</p>}</div>
                                    </div>
                                </div>
                                <div className="pt-4 border-t"><h3 className="text-md font-semibold text-gray-800 mb-2">اطلاعات تماس (اختیاری)</h3>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">تلفن</label><input {...beneficiaryForm.register('phone')} className="w-full border p-2 rounded-md" /></div>
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">ایمیل</label><input {...beneficiaryForm.register('email')} className="w-full border p-2 rounded-md" />{beneficiaryForm.formState.errors.email && <p className="text-red-500 text-xs mt-1">{String(beneficiaryForm.formState.errors.email.message)}</p>}</div>
                                        <div className="sm:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">آدرس</label><textarea {...beneficiaryForm.register('address')} className="w-full border p-2 rounded-md" rows={2}/></div>
                                    </div>
                                </div>
                            </div>
                            <div className="flex justify-end gap-2 p-4 border-t bg-gray-50"><button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}</button></div>
                        </form>
                    ) : (
                        <form onSubmit={personForm.handleSubmit(onPersonSubmit)}>
                            <div className="p-6 max-h-[80vh] overflow-y-auto space-y-4">
                               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">نام</label><input {...personForm.register('firstName')} className="w-full border p-2 rounded-md" />{personForm.formState.errors.firstName && <p className="text-red-500 text-xs mt-1">{String(personForm.formState.errors.firstName.message)}</p>}</div>
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">نام خانوادگی</label><input {...personForm.register('lastName')} className="w-full border p-2 rounded-md" />{personForm.formState.errors.lastName && <p className="text-red-500 text-xs mt-1">{String(personForm.formState.errors.lastName.message)}</p>}</div>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">کد پرسنلی</label><input {...personForm.register('personnelCode')} className="w-full border p-2 rounded-md" /></div>
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">کد ملی</label><input {...personForm.register('nationalId')} className="w-full border p-2 rounded-md" />{personForm.formState.errors.nationalId && <p className="text-red-500 text-xs mt-1">{String(personForm.formState.errors.nationalId.message)}</p>}</div>
                                </div>
                                <div className="pt-4 border-t"><h3 className="text-md font-semibold text-gray-800 mb-2">اطلاعات سازمانی (اختیاری)</h3>
                                    <div><label className="block text-sm font-medium text-gray-700 mb-1">واحد سازمانی / سمت</label><select {...personForm.register('unitId')} className="w-full border p-2 rounded-md bg-white"><option value="">بدون سمت</option>{units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select>{personForm.formState.errors.unitId && <p className="text-red-500 text-xs mt-1">{String(personForm.formState.errors.unitId.message)}</p>}</div>
                                </div>
                                 <div className="pt-4 border-t"><h3 className="text-md font-semibold text-gray-800 mb-2">اطلاعات مالی (اختیاری)</h3>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره حساب</label><input {...personForm.register('accountNumber')} className="w-full border p-2 rounded-md" /></div>
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">شماره کارت</label><input {...personForm.register('cardNumber')} className="w-full border p-2 rounded-md" /></div>
                                        <div className="sm:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">شماره شبا (IBAN)</label><input {...personForm.register('iban')} className="w-full border p-2 rounded-md" dir="ltr" /></div>
                                        <div><label className="block text-sm font-medium text-gray-700 mb-1">سقف تنخواه</label><input type="number" {...personForm.register('pettyCashLimit')} className="w-full border p-2 rounded-md" /></div>
                                    </div>
                                </div>
                            </div>
                            <div className="flex justify-end gap-2 p-4 border-t bg-gray-50"><button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}</button></div>
                        </form>
                    )}
                </Modal>
            )}
        </section>
    );
};

export default PersonsPage;