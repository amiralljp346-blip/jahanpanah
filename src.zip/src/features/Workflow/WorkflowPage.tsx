
import React, { useState, useEffect } from 'react';
import { useForm, useFieldArray, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Workflow, WorkflowSchema, WorkflowData, PaginatedResponse, AssigneeRule, Person, Role, Unit, RequestCategory } from '../../types';
import { workflowsApi, personsApi, rolesApi, unitsApi, requestCategoriesApi } from '../../services/api';
import Modal from '../../components/Modal';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import WorkflowCard from './WorkflowCard';
import { useToast } from '../../hooks/useToast';
import { useServerStatus } from '../../context/ServerStatusContext';
import { useQuery } from '@tanstack/react-query';

type WorkflowFormData = z.infer<typeof WorkflowSchema>;

const WorkflowPage: React.FC = () => {
  const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('WORKFLOW');
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(null);
  const toast = useToast();
  const [page] = useState(1);
  const { status: serverStatus } = useServerStatus();

  // FIX: Data for cards and modal should be fetched when the page loads to prevent rendering errors.
  const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({ 
      queryKey: ['persons_all_workflow'], 
      queryFn: () => personsApi.getAllUnpaginated({ isSystemUser: true }), 
      enabled: serverStatus === 'online' 
  });
  const { data: roles, isLoading: isRolesLoading } = useQuery<Role[]>({ 
      queryKey: ['roles_all'], 
      queryFn: () => rolesApi.getAllUnpaginated(), 
      enabled: serverStatus === 'online' 
  });
  const { data: units, isLoading: isUnitsLoading } = useQuery<Unit[]>({ 
      queryKey: ['units_all'], 
      queryFn: () => unitsApi.getAllUnpaginated(), 
      enabled: serverStatus === 'online' 
  });
  const { data: categories, isLoading: isCategoriesLoading } = useQuery<RequestCategory[]>({ 
      queryKey: ['requestCategories_all'], 
      queryFn: () => requestCategoriesApi.getAllUnpaginated(), 
      enabled: serverStatus === 'online' 
  });

  const { data: workflowsResponse, isLoading: isWorkflowsLoading } = useQuery<PaginatedResponse<Workflow>>({
      queryKey: ['workflows', page],
      queryFn: () => workflowsApi.getAll(page),
      enabled: serverStatus === 'online',
  });

  const { register, control, handleSubmit, reset, watch, formState: { errors } } = useForm<WorkflowFormData>({
    resolver: zodResolver(WorkflowSchema),
    defaultValues: { name: '', requestCategoryId: '', steps: [{ name: '', assigneeRule: { type: 'USER' } }] }
  });

  const { fields, append, remove } = useFieldArray({ control, name: "steps" });
  const watchedSteps = watch("steps");

  useEffect(() => {
    if (isModalOpen) {
      if (selectedWorkflow) {
        reset({
          name: selectedWorkflow.name,
          requestCategoryId: String(selectedWorkflow.requestCategoryId),
          steps: selectedWorkflow.steps.map(s => ({
            ...s,
            assigneeRule: {
              ...s.assigneeRule,
              userId: s.assigneeRule.userId?.toString(),
              roleId: s.assigneeRule.roleId?.toString(),
              unitId: s.assigneeRule.unitId?.toString(),
              positionId: s.assigneeRule.positionId?.toString(),
            }
          }))
        });
      } else {
        reset({ name: '', requestCategoryId: '', steps: [{ name: '', assigneeRule: { type: 'USER' } }] });
      }
    }
  }, [selectedWorkflow, isModalOpen, reset]);

  const mutation = useMutation({
    mutationFn: (data: { formData: WorkflowFormData, id?: number }) => {
        const finalData: WorkflowData = {
            name: data.formData.name,
            requestCategoryId: Number(data.formData.requestCategoryId),
            steps: data.formData.steps.map((step, index) => {
                const { type, userId, roleId, unitId, positionId } = step.assigneeRule;
                let cleanRule: { [key: string]: any } = { type };

                switch (type) {
                    case 'USER':
                        if (userId) cleanRule.userId = Number(userId);
                        break;
                    case 'ROLE':
                        if (roleId) cleanRule.roleId = Number(roleId);
                        break;
                    case 'UNIT_AND_ROLE':
                        if (unitId) cleanRule.unitId = Number(unitId);
                        if (roleId) cleanRule.roleId = Number(roleId);
                        break;
                    case 'POSITION':
                        if (positionId) cleanRule.positionId = Number(positionId);
                        break;
                    case 'UNIT_MANAGER':
                        break;
                }

                return {
                    id: (selectedWorkflow?.steps[index] as any)?.id || Date.now() + index,
                    name: step.name,
                    assigneeRule: cleanRule as AssigneeRule,
                };
            })
        };
        return data.id ? workflowsApi.update(data.id, finalData) : workflowsApi.create(finalData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      setIsModalOpen(false);
      toast.success('گردش کار با موفقیت ذخیره شد.');
    },
    onError: (err: Error) => toast.error(`خطا: ${err.message}`)
  });
  
  const deleteMutation = useMutation({
    mutationFn: (id: number) => workflowsApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      toast.success('گردش کار با موفقیت حذف شد.');
    },
    onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`)
  });

  const onSubmit: SubmitHandler<WorkflowFormData> = (data) => mutation.mutate({ formData: data, id: selectedWorkflow?.id });
  const handleDelete = (id: number) => { if (window.confirm('آیا از حذف این گردش کار مطمئن هستید؟')) deleteMutation.mutate(id); };
  const openModal = (wf: Workflow | null = null) => { setSelectedWorkflow(wf); setIsModalOpen(true); };

  if (!canRead) return <AccessDenied />;

  const isLoadingData = isPersonsLoading || isRolesLoading || isUnitsLoading || isCategoriesLoading || isWorkflowsLoading;

  return (
    <section className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">مدیریت گردش‌های کاری</h2>
        <button onClick={() => openModal()} disabled={!canCreate || !canUpdate} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold flex items-center gap-2 disabled:bg-gray-400">افزودن گردش کار جدید</button>
      </div>

      {isLoadingData && serverStatus === 'online' ? <p>در حال بارگذاری گردش‌های کاری...</p> : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(workflowsResponse?.data || []).map(wf => (
              <WorkflowCard 
                key={wf.id} 
                workflow={wf} 
                persons={persons || []}
                roles={roles || []}
                units={units || []}
                requestCategories={categories || []}
                onEdit={openModal} 
                onDelete={handleDelete} 
              />
            ))}
          </div>
      )}
      
      {isModalOpen && (
        <Modal title={selectedWorkflow ? "ویرایش گردش کار" : "ایجاد گردش کار جدید"} onClose={() => setIsModalOpen(false)} size="3xl">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><label className="block text-sm font-medium">نام گردش کار</label><input {...register("name")} className="w-full border p-2 rounded" />{errors.name && <p className="text-red-500 text-xs mt-1">{String(errors.name.message)}</p>}</div>
                  <div><label className="block text-sm font-medium">برای نوع درخواست</label><select {...register("requestCategoryId")} className="w-full border p-2 rounded bg-white"><option value="">...</option>{(categories || []).map(c => <option key={c.id} value={c.id}>{c.label}</option>)}</select>{errors.requestCategoryId && <p className="text-red-500 text-xs mt-1">{String(errors.requestCategoryId.message)}</p>}</div>
                </div>
                <div className="pt-4 border-t"><h3 className="font-semibold mb-2">گام‌های فرآیند</h3><div className="space-y-3">{fields.map((field, index) => (<div key={field.id} className="p-3 border rounded-lg bg-gray-50 space-y-2"><div className="flex justify-between items-center"><input {...register(`steps.${index}.name`)} placeholder="نام گام" className="border p-1.5 rounded flex-grow" /><button type="button" onClick={() => remove(index)} className="text-red-500 font-bold hover:text-red-700 ml-2">✖</button></div><div><label className="text-xs font-medium">مسئول</label><select {...register(`steps.${index}.assigneeRule.type`)} className="w-full border p-1 rounded bg-white text-sm"><option value="USER">کاربر خاص</option><option value="ROLE">نقش خاص</option><option value="UNIT_MANAGER">مدیر واحد درخواست کننده</option><option value="UNIT_AND_ROLE">نقش در واحد خاص</option></select></div>{watchedSteps[index]?.assigneeRule.type === 'USER' && <div><select {...register(`steps.${index}.assigneeRule.userId`)} className="w-full border p-1 rounded bg-white text-sm"><option value="">انتخاب کاربر</option>{(persons || []).map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}</select></div>}{watchedSteps[index]?.assigneeRule.type === 'ROLE' && <div><select {...register(`steps.${index}.assigneeRule.roleId`)} className="w-full border p-1 rounded bg-white text-sm"><option value="">انتخاب نقش</option>{(roles || []).map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>}{watchedSteps[index]?.assigneeRule.type === 'UNIT_AND_ROLE' && <div className="grid grid-cols-2 gap-2"><select {...register(`steps.${index}.assigneeRule.unitId`)} className="w-full border p-1 rounded bg-white text-sm"><option value="">انتخاب واحد</option>{(units || []).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select><select {...register(`steps.${index}.assigneeRule.roleId`)} className="w-full border p-1 rounded bg-white text-sm"><option value="">انتخاب نقش</option>{(roles || []).map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>}</div>))}</div><button type="button" onClick={() => append({ name: '', assigneeRule: { type: 'USER' } })} className="text-sm text-blue-600 mt-2 font-semibold hover:underline">+ افزودن گام</button>{errors.steps && <p className="text-red-500 text-xs mt-1">{(errors.steps.message || (errors.steps as any).root?.message) as string}</p>}</div>
              </div>
              <div className="flex justify-end gap-2 p-4 border-t bg-gray-50">
                <button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button>
                <button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? 'در حال ذخیره...' : 'ذخیره'}</button>
              </div>
            </form>
        </Modal>
      )}
    </section>
  );
};

export default WorkflowPage;
