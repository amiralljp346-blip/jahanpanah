
import React, { useState, useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Role, RoleData, RoleSchema, PaginatedResponse, Person } from '../../types';
import { rolesApi, personsApi } from '../../services/api';
import Modal from '../../components/Modal';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { ALL_PERMISSIONS_LIST, PERMISSION_MAP, PERMISSIONS } from '../../constants/resources';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { z } from 'zod';
import { useServerStatus } from '../../context/ServerStatusContext';

type FormData = z.infer<typeof RoleSchema>;

const RolesPage: React.FC = () => {
    const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('ROLES');
    const queryClient = useQueryClient();
    const toast = useToast();
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const { status: serverStatus } = useServerStatus();

    const { data: rolesResponse, isLoading: isRolesLoading } = useQuery<PaginatedResponse<Role>>({
        queryKey: ['roles', page, debouncedSearch],
        queryFn: () => rolesApi.getAll(page, debouncedSearch),
        placeholderData: (previousData) => previousData,
        enabled: serverStatus === 'online',
    });
    
    const { data: persons, isLoading: isPersonsLoading } = useQuery<Person[]>({
        queryKey: ['persons_all'],
        queryFn: () => personsApi.getAllUnpaginated(),
        enabled: serverStatus === 'online',
    });

    const roles = rolesResponse?.data || [];
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [viewingUsersOfRole, setViewingUsersOfRole] = useState<Role | null>(null);
    const [selectedRole, setSelectedRole] = useState<Role | null>(null);
    const [activeTab, setActiveTab] = useState<'details' | 'permissions'>('details');
    const [currentPermissions, setCurrentPermissions] = useState<Set<string>>(new Set());

    const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({ 
        resolver: zodResolver(RoleSchema),
        defaultValues: { status: 'ACTIVE' },
    });

    useEffect(() => {
        setPage(1);
    }, [debouncedSearch]);
    
    useEffect(() => {
        if (isModalOpen) {
            if (selectedRole) {
                reset({ name: selectedRole.name, description: selectedRole.description, status: selectedRole.status || 'ACTIVE' });
                
                let permissionsToSet: string[] = [];
                if (selectedRole.permissions) {
                    if (Array.isArray(selectedRole.permissions)) {
                        permissionsToSet = selectedRole.permissions;
                    } else if (typeof selectedRole.permissions === 'string') {
                        try {
                            const parsed = JSON.parse(selectedRole.permissions);
                            if (Array.isArray(parsed)) {
                                permissionsToSet = parsed;
                            }
                        } catch (e) {
                            // Suppress parsing errors, will default to an empty set
                            console.error("Failed to parse role permissions:", e);
                        }
                    }
                }
                setCurrentPermissions(new Set(permissionsToSet));
            } else {
                reset({ name: '', description: '', status: 'ACTIVE' });
                setCurrentPermissions(new Set());
            }
            setActiveTab('details');
        }
    }, [selectedRole, isModalOpen, reset]);

    const mutation = useMutation({
        mutationFn: (data: { formData: FormData, permissions: string[], id?: number }) => {
            const rolePayload: RoleData = { ...data.formData, permissions: data.permissions };
            return data.id ? rolesApi.update(data.id, rolePayload) : rolesApi.create(rolePayload);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['roles'] });
            queryClient.invalidateQueries({ queryKey: ['persons'] });
            queryClient.invalidateQueries({ queryKey: ['roles_all']});
            setIsModalOpen(false);
            toast.success('نقش با موفقیت ذخیره شد.');
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const deleteMutation = useMutation({
        mutationFn: (id: number) => rolesApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['roles'] });
            queryClient.invalidateQueries({ queryKey: ['roles_all']});
            toast.success('نقش با موفقیت حذف شد.');
        },
        onError: (err: Error) => toast.error(`خطا در حذف: ${err.message}`),
    });
    
    const handlePermissionChange = (permission: string, checked: boolean) => {
        const newPermissions = new Set(currentPermissions);
        if (checked) newPermissions.add(permission); else newPermissions.delete(permission);
        setCurrentPermissions(newPermissions);
    };

    const onSubmit: SubmitHandler<FormData> = (data) => mutation.mutate({ formData: data, permissions: Array.from(currentPermissions), id: selectedRole?.id });
    const handleDelete = (id: number) => { if (window.confirm('آیا از حذف این نقش مطمئن هستید؟')) deleteMutation.mutate(id); };
    const openModalToCreate = () => { setSelectedRole(null); setIsModalOpen(true); };
    const openModalToEdit = (role: Role) => { setSelectedRole(role); setIsModalOpen(true); };
    
    const usersWithRole = viewingUsersOfRole ? (persons || []).filter(p => Array.isArray(p.roleIds) && p.roleIds.includes(viewingUsersOfRole.id)) : [];

    if (!canRead) return <AccessDenied />;

    const isLoading = isRolesLoading || isPersonsLoading;

    return (
        <section className="space-y-6">
            <div className="flex justify-between items-center"><h2 className="text-2xl font-bold text-gray-800">مدیریت نقش‌ها</h2></div>
            
            <div className="p-3 bg-gray-100 border border-gray-300 rounded-md grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <div className="flex items-center gap-2 md:col-span-2">
                    <label htmlFor="search-title" className="text-sm font-semibold text-gray-700 flex-shrink-0">عنوان نقش:</label>
                    <input id="search-title" name="title" type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full p-1.5 border border-gray-400 rounded-sm text-sm" />
                </div>
                <div className="flex items-center gap-2">
                    <button type="button" className="px-4 py-1.5 bg-gray-200 border border-gray-400 rounded-sm text-sm font-semibold">جستجو</button>
                </div>
            </div>

            <div className="bg-white border rounded-lg shadow-sm overflow-hidden">
                <div className="flex justify-end p-2 border-b gap-2">
                    <button onClick={openModalToCreate} disabled={!canCreate} className="text-xs px-3 py-1 bg-gray-200 border border-gray-400 rounded-sm disabled:opacity-50">جدید</button>
                </div>
                 <table className="w-full text-sm">
                    <thead className="bg-gray-100 text-gray-700">
                        <tr>
                            <th className="p-2 text-right font-semibold">عنوان نقش</th>
                            <th className="p-2 text-right font-semibold">توضیح</th>
                            <th className="p-2 text-right font-semibold">وضعیت</th>
                            <th className="p-2 text-center font-semibold">صاحبان نقش</th>
                            <th className="p-2 text-center font-semibold">عملیات</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y">
                        {isLoading && serverStatus !== 'offline' ? (
                            <tr><td colSpan={5} className="text-center p-8">در حال بارگذاری...</td></tr>
                        ) : roles.length === 0 ? (
                            <tr><td colSpan={5} className="text-center p-8 text-gray-500">نقشی یافت نشد.</td></tr>
                        ) : (
                            roles.map(role => (
                                <tr key={role.id} className="hover:bg-gray-50">
                                    <td className="p-3 font-semibold text-gray-800">{role.name}</td>
                                    <td className="p-3 text-gray-600">{role.description}</td>
                                    <td className="p-3">
                                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${role.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                            {role.status === 'ACTIVE' ? 'فعال' : 'غیرفعال'}
                                        </span>
                                    </td>
                                    <td className="p-3 text-center">
                                        <button onClick={() => setViewingUsersOfRole(role)} className="text-blue-600 hover:underline">
                                            {(persons || []).filter(p => Array.isArray(p.roleIds) && p.roleIds.includes(role.id)).length} نفر
                                        </button>
                                    </td>
                                    <td className="p-3 text-center">
                                        <div className="flex justify-center gap-4 text-xs">
                                            <button onClick={() => openModalToEdit(role)} disabled={!canUpdate} className="font-semibold text-blue-600 hover:underline disabled:text-gray-400">ویرایش</button>
                                            <button onClick={() => handleDelete(role.id)} disabled={!canDelete} className="font-semibold text-red-600 hover:underline disabled:text-gray-400">حذف</button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                 </table>
            </div>

            {viewingUsersOfRole && <Modal title={`کاربران با نقش: ${viewingUsersOfRole.name}`} onClose={() => setViewingUsersOfRole(null)} size="md"><div className="p-4">{usersWithRole.length > 0 ? <ul className="space-y-2">{usersWithRole.map(p => <li key={p.id} className="p-2 bg-gray-100 rounded">{p.fullName}</li>)}</ul> : <p className="text-center text-gray-500 p-4">هیچ کاربری این نقش را ندارد.</p>}</div></Modal>}
            {isModalOpen && <Modal title={selectedRole ? 'ویرایش نقش' : 'ایجاد نقش جدید'} onClose={() => setIsModalOpen(false)} size="3xl"><form onSubmit={handleSubmit(onSubmit)}><div className="border-b border-gray-200"><nav className="flex -mb-px"><button type="button" onClick={() => setActiveTab('details')} className={`py-3 px-5 font-semibold text-sm ${activeTab === 'details' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>مشخصات نقش</button><button type="button" onClick={() => setActiveTab('permissions')} className={`py-3 px-5 font-semibold text-sm ${activeTab === 'permissions' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>دسترسی‌ها</button></nav></div><div className="p-6 max-h-[60vh] overflow-y-auto">{activeTab === 'details' && <div className="space-y-4"><div><label className="block text-sm font-medium text-gray-700 mb-1">عنوان نقش</label><input {...register('name')} className="w-full border p-2 rounded-md" />{errors.name && <p className="text-red-500 text-xs mt-1">{String(errors.name.message)}</p>}</div><div><label className="block text-sm font-medium text-gray-700 mb-1">توضیحات</label><textarea {...register('description')} rows={3} className="w-full border p-2 rounded-md" /></div><div><label className="block text-sm font-medium text-gray-700 mb-1">وضعیت</label><select {...register('status')} className="w-full border p-2 rounded bg-white"><option value="ACTIVE">فعال</option><option value="INACTIVE">غیرفعال</option></select>{errors.status && <p className="text-red-500 text-xs mt-1">{String(errors.status.message)}</p>}</div></div>}{activeTab === 'permissions' && <div className="space-y-4">{ALL_PERMISSIONS_LIST.map(({ resourceKey, resourceLabel, permissions }) => <div key={resourceKey} className="p-3 border rounded-lg"><h4 className="font-bold text-gray-800 mb-2">{resourceLabel}</h4><div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{permissions.map(({ key, label }) => { const pStr = (PERMISSION_MAP[resourceKey as keyof typeof PERMISSION_MAP] as any)[key as keyof typeof PERMISSIONS]; return <label key={pStr} className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={currentPermissions.has(pStr)} onChange={e => handlePermissionChange(pStr, e.target.checked)} /> {label}</label>; })}</div></div>)}</div>}</div><div className="flex justify-end gap-2 p-4 border-t bg-gray-50"><button type="button" onClick={() => setIsModalOpen(false)} className="bg-gray-200 px-4 py-2 rounded font-semibold">لغو</button><button type="submit" disabled={mutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded disabled:bg-gray-400 font-semibold">{mutation.isPending ? '...' : 'ذخیره'}</button></div></form></Modal>}
        </section>
    );
};

export default RolesPage;