
import React, { useState, useMemo, useEffect } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useForm, SubmitHandler, Resolver } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { Person, PaginatedResponse, createUserRolesEditSchema, UserPasswordResetSchema, NewUserSchema, Role } from '../../types';
import { personsApi, rolesApi } from '../../services/api';
import { DataTable, ColumnDef } from '../../components/DataTable';
import Modal from '../../components/Modal';
import { usePermissions } from '../../hooks/usePermissions';
import AccessDenied from '../../components/AccessDenied';
import { z } from 'zod';
import { useToast } from '../../hooks/useToast';
import { useDebounce } from '../../hooks/useDebounce';
import { generateUsernameAndEmail } from '../../utils/formatters';
import { ALL_PERMISSIONS_LIST, PERMISSION_MAP, PERMISSIONS } from '../../constants/resources';
import { useServerStatus } from '../../context/ServerStatusContext';

type UserRolesEditFormData = z.infer<ReturnType<typeof createUserRolesEditSchema>>;
type NewUserFormData = z.infer<typeof NewUserSchema>;

// Internal component for selecting a person to grant access to
const SelectPersonModal: React.FC<{
    onSelect: (person: Person) => void;
    onClose: () => void;
}> = ({ onSelect, onClose }) => {
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);
    const { status: serverStatus } = useServerStatus();

    const { data: personsResponse, isLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['persons_for_new_user', page, debouncedSearch],
        queryFn: () => personsApi.getAll(page, debouncedSearch, { isSystemUser: false, hasUnit: true }),
        enabled: serverStatus === 'online',
    });

    const columns: ColumnDef<Person>[] = [
        { accessorKey: 'firstName', header: 'نام' },
        { accessorKey: 'lastName', header: 'نام خانوادگی' },
        { accessorKey: 'personnelCode', header: 'کد پرسنلی' },
        { accessorKey: 'unitName', header: 'واحد / سمت' },
        {
            accessorKey: 'actions', header: 'انتخاب', cell: (person) => (
                <button onClick={() => onSelect(person)} className="bg-blue-500 text-white px-3 py-1 text-sm rounded hover:bg-blue-600">
                    انتخاب
                </button>
            )
        }
    ];

    return (
        <Modal title="انتخاب شخص برای ایجاد کاربر" onClose={onClose} size="3xl">
            <div className="p-4 space-y-4">
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو بر اساس نام، نام خانوادگی، کد پرسنلی..."
                    className="w-full p-2 border rounded-md"
                />
                {isLoading && serverStatus !== 'online' ? <p>در حال بارگذاری...</p> : (
                    <DataTable
                        columns={columns}
                        data={personsResponse?.data || []}
                        pagination={{ page, total: personsResponse?.total || 0, itemsPerPage: 10 }}
                        onPageChange={setPage}
                    />
                )}
            </div>
        </Modal>
    );
};


const SecurityPage: React.FC = () => {
    const { read: canRead, create: canCreate, update: canUpdate, delete: canDelete } = usePermissions('SECURITY');
    const queryClient = useQueryClient();
    const { status: serverStatus } = useServerStatus();
    const { data: roles, isLoading: isRolesLoading } = useQuery<Role[]>({ 
        queryKey: ['roles_all'], 
        queryFn: () => rolesApi.getAllUnpaginated(), 
        enabled: serverStatus === 'online'
    });
    const toast = useToast();
    const [activeTab, setActiveTab] = useState('list');

    // State and forms for "List Users" tab
    const [listPage, setListPage] = useState(1);
    const [listSearch, setListSearch] = useState({ q: '', personnelCode: '' });
    const debouncedListSearch = useDebounce(listSearch, 300);
    const [modalState, setModalState] = useState<{ type: 'password' | 'delete' | 'edit' | null; user: Person | null }>({ type: null, user: null });

    // State for "Define New User" wizard
    const [isSelectPersonModalOpen, setIsSelectPersonModalOpen] = useState(false);
    const [wizardStep, setWizardStep] = useState(1);
    const [wizardData, setWizardData] = useState<Partial<NewUserFormData>>({});
    const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);


    const { data: usersResponse, isLoading: isUsersLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['system_users', listPage, debouncedListSearch],
        queryFn: () => personsApi.getAll(listPage, debouncedListSearch.q, { isSystemUser: true, personnelCode: debouncedListSearch.personnelCode }),
        placeholderData: (previousData) => previousData,
        enabled: activeTab === 'list' && serverStatus === 'online',
    });

    useEffect(() => { setListPage(1); }, [debouncedListSearch]);
    
    // --- FORMS ---
    const UserRolesEditSchema = useMemo(() => createUserRolesEditSchema(), []);
    const { register: editRegister, handleSubmit: handleEditSubmit, reset: editReset } = useForm<UserRolesEditFormData>({ resolver: zodResolver(UserRolesEditSchema) as unknown as Resolver<UserRolesEditFormData> });
    const { register: pwdRegister, handleSubmit: handlePwdSubmit, reset: pwdReset, formState: { errors: pwdErrors } } = useForm<z.infer<typeof UserPasswordResetSchema>>({ resolver: zodResolver(UserPasswordResetSchema) });
    const { register: newUserRegister, handleSubmit: handleNewUserSubmit, reset: newUserReset, setValue: setNewUserValue, getValues: getNewUserValues, trigger: triggerNewUserForm, formState: { errors } } = useForm<NewUserFormData>({ resolver: zodResolver(NewUserSchema) as unknown as Resolver<NewUserFormData>, defaultValues: { status: 'ACTIVE', forcePasswordChange: true, passwordNoExpiration: false, roleIds: [] } });

    // --- MUTATIONS ---
    const newUserMutation = useMutation({
        mutationFn: (data: { formData: NewUserFormData, id: number }) => {
            const { personId, confirmPassword, description, ...payload } = data.formData;
            return personsApi.update(data.id, { ...payload, isSystemUser: true });
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['system_users'] });
            queryClient.invalidateQueries({ queryKey: ['persons_for_new_user'] });
            toast.success("کاربر با موفقیت به سیستم اضافه شد.");
            setSelectedPerson(null);
            newUserReset();
            setWizardStep(1);
            setWizardData({});
            setActiveTab('list');
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const editUserMutation = useMutation({
        mutationFn: (data: { formData: UserRolesEditFormData, id: number }) => personsApi.update(data.id, data.formData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['system_users'] });
            toast.success("نقش‌های کاربر ویرایش شد.");
            setModalState({ type: null, user: null });
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const passwordMutation = useMutation({
        mutationFn: (data: { userId: number, newPassword: string }) => personsApi.resetPassword(data.userId, data.newPassword),
        onSuccess: () => { toast.success("رمز عبور بازنشانی شد."); setModalState({ type: null, user: null }); },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    const revokeAccessMutation = useMutation({
        mutationFn: (userId: number) => personsApi.revokeAccess(userId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['system_users'] });
            queryClient.invalidateQueries({ queryKey: ['persons_for_new_user'] });
            toast.success("دسترسی کاربر لغو شد.");
            setModalState({ type: null, user: null });
        },
        onError: (err: Error) => toast.error(`خطا: ${err.message}`),
    });

    // --- Effects ---
    useEffect(() => {
        if (modalState.type === 'edit' && modalState.user) {
            editReset({ roleIds: modalState.user.roleIds || [] });
        }
    }, [modalState, editReset]);

    // --- Handlers ---
    const onPasswordSubmit: SubmitHandler<z.infer<typeof UserPasswordResetSchema>> = (data) => { if (modalState.user) passwordMutation.mutate({ userId: modalState.user.id, newPassword: data.password }); };
    const onEditSubmit: SubmitHandler<UserRolesEditFormData> = (data) => { if (modalState.user) editUserMutation.mutate({ formData: data, id: modalState.user.id }); };
    
    const handleOpenModal = (type: 'password' | 'delete' | 'edit', user: Person) => {
        pwdReset({ password: '' });
        setModalState({ type, user });
    };

    const handleSelectPerson = (person: Person) => {
        setSelectedPerson(person);
        const fullName = `${person.firstName} ${person.lastName}`;
        const { username } = generateUsernameAndEmail(fullName);
        setNewUserValue('personId', person.id);
        setNewUserValue('username', username);
        setIsSelectPersonModalOpen(false);
    };

    const handleWizardNext = async () => {
        let isStepValid = false;
        if (wizardStep === 1) {
            isStepValid = await triggerNewUserForm(['username', 'password', 'confirmPassword']);
        } else if (wizardStep === 2) {
            isStepValid = await triggerNewUserForm(['roleIds']);
        }
        
        if (isStepValid) {
            setWizardData(prev => ({...prev, ...getNewUserValues()}));
            setWizardStep(prev => prev + 1);
        }
    };
    
    const handleWizardPrev = () => {
        setWizardData(prev => ({...prev, ...getNewUserValues()}));
        setWizardStep(prev => prev - 1);
    };
    
    const handleFinalSubmit = () => {
        if (selectedPerson) {
            const finalData = { ...wizardData, ...getNewUserValues() } as NewUserFormData;
            newUserMutation.mutate({ formData: finalData, id: selectedPerson.id });
        }
    };
    
    const wizardPermissions = useMemo(() => {
        if (!roles || !wizardData.roleIds) return [];
        const selectedRoles = roles.filter(r => wizardData.roleIds?.includes(r.id));
        const permissionSet = new Set(selectedRoles.flatMap(r => r.permissions));
        return Array.from(permissionSet);
    }, [wizardData.roleIds, roles]);


    if (!canRead) return <AccessDenied />;

    const userColumns: ColumnDef<Person>[] = [
        { accessorKey: 'firstName', header: 'نام' },
        { accessorKey: 'lastName', header: 'نام خانوادگی' },
        { accessorKey: 'personnelCode', header: 'کد پرسنلی' },
        { accessorKey: 'username', header: 'نام کاربری' },
        { accessorKey: 'roleNames', header: 'نقش‌ها', cell: (p) => (p.roleNames || []).join('، ') },
        { accessorKey: 'actions', header: 'عملیات', width: '200px', cell: (user) => (
            <div className="flex justify-center gap-4">
                <button onClick={() => handleOpenModal('edit', user)} disabled={!canUpdate} className="text-green-600 hover:underline font-semibold disabled:text-gray-400">ویرایش نقش</button>
                <button onClick={() => handleOpenModal('password', user)} disabled={!canUpdate} className="text-blue-600 hover:underline font-semibold disabled:text-gray-400">بازنشانی رمز</button>
                <button onClick={() => handleOpenModal('delete', user)} disabled={!canDelete} className="text-red-600 hover:underline font-semibold disabled:text-gray-400">لغو دسترسی</button>
            </div>
        )}
    ];

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">مدیریت کاربران و امنیت</h2>
            <div className="border-b border-gray-200">
                <nav className="flex -mb-px gap-6">
                    <button onClick={() => setActiveTab('list')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'list' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>لیست کاربران</button>
                    {canCreate && <button onClick={() => setActiveTab('create')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'create' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}>تعریف کاربر جدید</button>}
                </nav>
            </div>
            
            {activeTab === 'list' && (
                <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg border">
                        <input type="text" value={listSearch.q} onChange={(e) => setListSearch(s => ({ ...s, q: e.target.value }))} placeholder="جستجو نام، نام خانوادگی، کد ملی..." className="p-2 border rounded-md" />
                        <input type="text" value={listSearch.personnelCode} onChange={(e) => setListSearch(s => ({ ...s, personnelCode: e.target.value }))} placeholder="کد پرسنلی..." className="p-2 border rounded-md" />
                    </div>
                    {isUsersLoading && serverStatus !== 'online' ? <p>در حال بارگذاری...</p> :
                        <DataTable columns={userColumns} data={usersResponse?.data || []} pagination={{ page: listPage, total: usersResponse?.total || 0, itemsPerPage: 20 }} onPageChange={setListPage} />
                    }
                </div>
            )}

            {activeTab === 'create' && (
                <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md border space-y-6">
                    {wizardStep === 1 && (
                        <div>
                            <h3 className="font-bold text-lg mb-4">مرحله ۱: انتخاب شخص و مشخصات کاربری</h3>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">نام</label>
                                <div className="flex items-center gap-2">
                                    <input value={selectedPerson ? `${selectedPerson.firstName} ${selectedPerson.lastName}` : ''} readOnly className="w-full border p-2 rounded-md bg-gray-100" />
                                    <button type="button" onClick={() => setIsSelectPersonModalOpen(true)} className="bg-blue-600 text-white px-4 py-2 rounded-md font-semibold">انتخاب</button>
                                </div>
                                {!selectedPerson && <p className="text-gray-500 text-xs mt-1">ابتدا یک شخص که دارای سمت سازمانی است را انتخاب کنید.</p>}
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                                <div className="md:col-span-1"><label className="block text-sm font-medium">شناسه کاربری</label><input {...newUserRegister('username')} className="w-full border p-2 rounded" disabled={!selectedPerson} />{errors.username && <p className="text-red-500 text-xs">{String(errors.username.message)}</p>}</div>
                                <div><label className="block text-sm font-medium">گذرواژه</label><input type="password" {...newUserRegister('password')} className="w-full border p-2 rounded" disabled={!selectedPerson} />{errors.password && <p className="text-red-500 text-xs">{String(errors.password.message)}</p>}</div>
                                <div><label className="block text-sm font-medium">تکرار گذرواژه</label><input type="password" {...newUserRegister('confirmPassword')} className="w-full border p-2 rounded" disabled={!selectedPerson} />{errors.confirmPassword && <p className="text-red-500 text-xs">{String(errors.confirmPassword.message)}</p>}</div>
                            </div>
                             <div className="mt-4"><label className="block text-sm font-medium">توضیح</label><textarea {...newUserRegister('description')} rows={3} className="w-full border p-2 rounded" disabled={!selectedPerson} /></div>
                            <div className="mt-4"><label className="block text-sm font-medium text-gray-700 mb-2">وضعیت</label><div className="flex gap-4"><label className="flex items-center gap-2"><input type="radio" value="ACTIVE" {...newUserRegister('status')} disabled={!selectedPerson} /> فعال</label><label className="flex items-center gap-2"><input type="radio" value="INACTIVE" {...newUserRegister('status')} disabled={!selectedPerson} /> غیرفعال</label></div></div>
                            <div className="space-y-2 mt-4"><label className="flex items-center gap-2"><input type="checkbox" {...newUserRegister('forcePasswordChange')} disabled={!selectedPerson} /> تغییر گذرواژه در اولین ورود به سیستم</label><label className="flex items-center gap-2"><input type="checkbox" {...newUserRegister('passwordNoExpiration')} disabled={!selectedPerson} /> عمر گذرواژه این کاربر بدون محدودیت باشد</label></div>
                        </div>
                    )}
                    {wizardStep === 2 && (
                         <div>
                            <h3 className="font-bold text-lg mb-4">مرحله ۲: تخصیص نقش</h3>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-1 border p-4 rounded-lg bg-gray-50 max-h-80 overflow-y-auto">{(roles || []).filter(r => r.status === 'ACTIVE').map(role => (<label key={role.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-gray-100 cursor-pointer"><input type="checkbox" value={role.id} {...newUserRegister('roleIds')} />{role.name}</label>))}<br/></div>
                             {errors.roleIds && <p className="text-red-500 text-xs col-span-full mt-2">{String(errors.roleIds.message)}</p>}
                        </div>
                    )}
                     {wizardStep === 3 && (
                        <div>
                            <h3 className="font-bold text-lg mb-4">مرحله ۳: بازبینی و تایید نهایی</h3>
                            <div className="space-y-4 p-4 border rounded-lg bg-gray-50">
                                <p><strong>نام شخص:</strong> {selectedPerson?.fullName}</p>
                                <p><strong>شناسه کاربری:</strong> {wizardData.username}</p>
                                <p><strong>نقش‌های تخصیص یافته:</strong> {(roles || []).filter(r => wizardData.roleIds?.includes(r.id)).map(r => r.name).join('، ')}</p>
                                <div><p className="font-bold">دسترسی‌های اعطا شده:</p><div className="text-xs text-gray-600 columns-2 md:columns-3 mt-2">{wizardPermissions.map(p => <div key={String(p)}>{String(p)}</div>)}</div></div>
                            </div>
                        </div>
                    )}
                    <div className="flex justify-end gap-2 pt-4 border-t">
                        {wizardStep > 1 && <button type="button" onClick={handleWizardPrev} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-md font-semibold">قبلی</button>}
                        {wizardStep < 3 && <button type="button" onClick={handleWizardNext} disabled={!selectedPerson} className="bg-blue-500 text-white px-4 py-2 rounded-md font-semibold disabled:bg-gray-300">بعدی</button>}
                        {wizardStep === 3 && <button type="button" onClick={handleFinalSubmit} disabled={newUserMutation.isPending} className="bg-green-600 text-white px-6 py-2 rounded-md font-semibold disabled:bg-gray-400">تایید نهایی و ایجاد کاربر</button>}
                    </div>
                </div>
            )}


            {isSelectPersonModalOpen && <SelectPersonModal onSelect={handleSelectPerson} onClose={() => setIsSelectPersonModalOpen(false)} />}
            {modalState.type === 'edit' && modalState.user && <Modal title={`ویرایش نقش‌های ${modalState.user.fullName}`} onClose={() => setModalState({ type: null, user: null })}><form onSubmit={handleEditSubmit(onEditSubmit)}><div className="p-6"><div><h3 className="text-md font-semibold text-gray-800 mb-2">نقش‌ها</h3><div className="grid grid-cols-2 md:grid-cols-3 gap-2">{(roles || []).map(role => (<label key={role.id} className="flex items-center gap-2 p-2 bg-white rounded-md border"><input type="checkbox" value={role.id} {...editRegister('roleIds')} />{role.name}</label>))}</div></div></div><div className="flex justify-end gap-2 p-4 border-t"><button type="button" onClick={() => setModalState({ type: null, user: null })} className="bg-gray-200 px-4 py-2 rounded">لغو</button><button type="submit" disabled={editUserMutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded">ذخیره</button></div></form></Modal>}
            {modalState.type === 'password' && modalState.user && <Modal title={`بازنشانی رمز عبور برای ${modalState.user.fullName}`} onClose={() => setModalState({ type: null, user: null })}><form onSubmit={handlePwdSubmit(onPasswordSubmit)} className="p-6 space-y-4"><div><label className="block text-sm font-medium">رمز عبور جدید</label><input type="password" {...pwdRegister('password')} className="w-full border p-2 rounded" />{pwdErrors.password && <p className="text-red-500 text-xs">{String(pwdErrors.password.message)}</p>}</div><div className="flex justify-end gap-2 pt-4 border-t"><button type="button" onClick={() => setModalState({ type: null, user: null })} className="bg-gray-200 px-4 py-2 rounded">لغو</button><button type="submit" disabled={passwordMutation.isPending} className="bg-green-500 text-white px-4 py-2 rounded">ذخیره</button></div></form></Modal>}
            {modalState.type === 'delete' && modalState.user && <Modal title={`لغو دسترسی کاربر ${modalState.user.fullName}`} onClose={() => setModalState({ type: null, user: null })}><div className="p-6 space-y-4"><p>آیا از لغو دسترسی کاربر <span className="font-bold">{modalState.user.fullName}</span> مطمئن هستید؟</p><p className="text-sm text-gray-600">این عمل نام کاربری و رمز عبور شخص را حذف کرده و او دیگر قادر به ورود به سیستم نخواهد بود.</p><div className="flex justify-end gap-2 pt-4 border-t"><button type="button" onClick={() => setModalState({ type: null, user: null })} className="bg-gray-200 px-4 py-2 rounded">انصراف</button><button onClick={() => revokeAccessMutation.mutate(modalState.user!.id)} disabled={revokeAccessMutation.isPending} className="bg-red-600 text-white px-4 py-2 rounded">تایید و لغو دسترسی</button></div></div></Modal>}
        </div>
    );
};

export default SecurityPage;