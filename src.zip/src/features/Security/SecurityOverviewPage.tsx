import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Person, PaginatedResponse, SecuritySummary } from '../../types';
import { usePermissions } from '../../hooks/usePermissions';
import { useDebounce } from '../../hooks/useDebounce';
import { securityApi, personsApi } from '../../services/api';
import AccessDenied from '../../components/AccessDenied';
import { DataTable, ColumnDef } from '../../components/DataTable';

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; }> = ({ title, value, icon }) => (
    <div className="bg-white p-4 rounded-lg shadow-sm border flex items-center gap-4">
        <div className="bg-blue-100 text-blue-600 rounded-full p-3">{icon}</div>
        <div>
            <p className="text-sm text-gray-500">{title}</p>
            <p className="text-2xl font-bold text-gray-800">{value}</p>
        </div>
    </div>
);

const SecurityOverviewPage: React.FC = () => {
    const { read: canRead } = usePermissions('SECURITY');
    const [page, setPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const debouncedSearch = useDebounce(searchQuery, 300);

    const { data: summary, isLoading: isSummaryLoading } = useQuery<SecuritySummary>({
        queryKey: ['security_summary'],
        queryFn: securityApi.getSummary,
        enabled: canRead,
    });

    const { data: usersResponse, isLoading: isUsersLoading } = useQuery<PaginatedResponse<Person>>({
        queryKey: ['system_users', page, debouncedSearch],
        queryFn: () => personsApi.getAll(page, debouncedSearch, { isSystemUser: true }),
        enabled: canRead,
    });
    
    const columns: ColumnDef<Person>[] = [
        { accessorKey: 'fullName', header: 'نام کامل' },
        { accessorKey: 'username', header: 'نام کاربری' },
        { accessorKey: 'roleNames', header: 'نقش‌ها', cell: (p) => (p.roleNames || []).join('، ') },
        { accessorKey: 'status', header: 'وضعیت', cell: (p) => p.status === 'ACTIVE' ? <span className="text-green-600 font-semibold">فعال</span> : <span className="text-red-600 font-semibold">غیرفعال</span> },
        { accessorKey: 'forcePasswordChange', header: 'تغییر رمز اجباری', cell: (p) => p.forcePasswordChange ? 'بله' : 'خیر' },
        { accessorKey: 'passwordNoExpiration', header: 'رمز بدون انقضا', cell: (p) => p.passwordNoExpiration ? 'بله' : 'خیر' },
    ];

    if (!canRead) {
        return <AccessDenied />;
    }

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">خلاصه وضعیت امنیتی</h2>
            
            {isSummaryLoading ? <div className="h-24 bg-gray-200 rounded-lg animate-pulse" /> : summary && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                     <StatCard title="کل کاربران سیستم" value={summary.totalUsers} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197" /></svg>} />
                     <StatCard title="کاربران مدیر سیستم" value={summary.adminUsers} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>} />
                     <StatCard title="نیاز به تغییر رمز" value={summary.forceChangeUsers} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>} />
                     <StatCard title="رمزهای بدون انقضا" value={summary.noExpiryUsers} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} />
                </div>
            )}
            
            <div className="space-y-4">
                <h3 className="text-xl font-bold text-gray-800">لیست کاربران سیستم</h3>
                 <div className="relative">
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="جستجو بر اساس نام یا نام کاربری..."
                        className="w-full p-2 pl-10 border rounded-md"
                    />
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                </div>

                {isUsersLoading ? <p>در حال بارگذاری لیست کاربران...</p> : (
                    <DataTable 
                        columns={columns}
                        data={usersResponse?.data || []}
                        pagination={{ page, total: usersResponse?.total || 0, itemsPerPage: 20 }}
                        onPageChange={setPage}
                    />
                )}
            </div>
        </div>
    );
};

export default SecurityOverviewPage;