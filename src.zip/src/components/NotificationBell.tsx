import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import * as ReactRouterDOM from 'react-router-dom';
const { useNavigate } = ReactRouterDOM;
import { notificationsApi } from '../services/api';
import { useAuth } from '../hooks/useAuth';
import { Notification } from '../types';

const NotificationBell: React.FC = () => {
    const { currentUser } = useAuth();
    const queryClient = useQueryClient();
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    const { data } = useQuery({
        queryKey: ['notifications', currentUser?.id],
        queryFn: () => notificationsApi.getForUser(currentUser!.id),
        enabled: !!currentUser,
        refetchInterval: 30000, // Poll every 30 seconds
    });

    const markAsReadMutation = useMutation({
        mutationFn: () => notificationsApi.markAllAsRead(currentUser!.id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notifications', currentUser?.id] });
        }
    });

    useEffect(() => {
        if (isOpen && data && data.unreadCount > 0) {
            markAsReadMutation.mutate();
        }
    }, [isOpen, data, markAsReadMutation]);
    
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [menuRef]);

    const handleNotificationClick = (notification: Notification) => {
        setIsOpen(false);
        navigate('/dashboard', { state: { viewRequestId: notification.link } });
    };
    
    const timeSince = (dateString: string) => {
        const seconds = Math.floor((new Date().getTime() - new Date(dateString).getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + " سال پیش";
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + " ماه پیش";
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + " روز پیش";
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + " ساعت پیش";
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + " دقیقه پیش";
        return "همین الان";
    };

    if (!currentUser) return null;

    return (
        <div className="relative" ref={menuRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-gray-600 hover:text-fuchsia-600 relative"
                aria-label={`شما ${data?.unreadCount || 0} اعلان خوانده نشده دارید`}
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {data && data.unreadCount > 0 && (
                    <span className="absolute top-0 right-0 block h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white" />
                )}
            </button>
            {isOpen && (
                <div className="absolute top-full left-0 mt-2 w-80 bg-white rounded-md shadow-lg border z-50 max-h-96 overflow-y-auto">
                    <div className="p-3 font-bold border-b text-gray-700">اعلانات</div>
                    {data?.notifications.length === 0 ? (
                        <p className="text-center text-sm text-gray-500 p-4">هیچ اعلان جدیدی وجود ندارد.</p>
                    ) : (
                        <div>
                            {data?.notifications.map(notification => (
                                <button
                                    key={notification.id}
                                    onClick={() => handleNotificationClick(notification)}
                                    className={`w-full text-right block px-4 py-3 text-sm border-b hover:bg-gray-50 ${!notification.isRead ? 'bg-blue-50' : ''}`}
                                >
                                    <p className="text-gray-800">{notification.message}</p>
                                    <p className="text-xs text-gray-500 mt-1">{timeSince(notification.createdAt)}</p>
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default NotificationBell;
