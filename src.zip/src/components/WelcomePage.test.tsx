import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
// FIX: Using a namespace import for react-router-dom to work around module resolution issues.
import * as ReactRouterDOM from 'react-router-dom';
const { MemoryRouter } = ReactRouterDOM;
// FIX: Replaced '@' alias with a relative path to resolve module error.
import WelcomePage from './WelcomePage';

describe('WelcomePage', () => {
  it('renders the welcome message and dashboard link', () => {
    render(
      <MemoryRouter>
        <WelcomePage />
      </MemoryRouter>
    );

    // Check for the main heading
    expect(screen.getByText(/به سامانه مدیریت زنجیره تامین خوش آمدید/i)).toBeInTheDocument();

    // Check for the link to the dashboard
    const dashboardLink = screen.getByRole('link', { name: /ورود به داشبورد/i });
    expect(dashboardLink).toBeInTheDocument();
    expect(dashboardLink).toHaveAttribute('href', '/dashboard');
  });
});
