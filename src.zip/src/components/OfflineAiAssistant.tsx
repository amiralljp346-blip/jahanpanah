import React, { useState, useMemo } from 'react';
// FIX: Replaced named import from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { useNavigate } = ReactRouterDOM;
import { useQuery, useQueryClient } from '@tanstack/react-query';
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { useAuth } from '../hooks/useAuth';
import { SupplyRequest, PETTY_CASH_ROLE_ID, Person, RequestCategory } from '../types';
import { workflowEngineApi, personsApi, requestCategoriesApi } from '../services/api';
import Modal from './Modal';
import RequestDetailsModal from '../features/Dashboard/RequestDetailsModal';
import { formatCurrency } from '../utils/formatters';
import { useToast } from '../hooks/useToast';

const OfflineAiAssistant: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [requestId, setRequestId] = useState('');
    const [selectedPettyCashHolderId, setSelectedPettyCashHolderId] = useState('');
    const [viewingRequest, setViewingRequest] = useState<SupplyRequest | null>(null);
    const [dateFrom, setDateFrom] = useState('');
    const [dateTo, setDateTo] = useState('');
    const [selectedRequestTypeId, setSelectedRequestTypeId] = useState('');

    const navigate = useNavigate();
    const toast = useToast();
    const queryClient = useQueryClient();
    const { currentUser } = useAuth();

    const { data: persons } = useQuery<Person[]>({
        queryKey: ['persons_all_for_assistant'],
        queryFn: () => personsApi.getAllUnpaginated(),
    });
    const { data: requestCategories } = useQuery<RequestCategory[]>({
        queryKey: ['requestCategories_all_for_assistant'],
        queryFn: () => requestCategoriesApi.getAllUnpaginated(),
    });


    const pettyCashHolders = useMemo(() => {
        if (!persons) return [];
        return persons.filter(p => p.roleIds?.includes(PETTY_CASH_ROLE_ID));
    }, [persons]);
    
    const selectedPettyCashHolder = useMemo(() => {
        if (!selectedPettyCashHolderId || !persons) return null;
        return persons.find(p => p.id === Number(selectedPettyCashHolderId));
    }, [selectedPettyCashHolderId, persons]);

    const userPermissions = useMemo(() => new Set(currentUser?.permissions || []), [currentUser]);
    const canManagePettyCash = userPermissions.has('PETTY_CASH_MANAGEMENT:read_all') || userPermissions.has('PETTY_CASH_MANAGEMENT:read_own_unit');

    // FIX: Removed deprecated `onSuccess` and `onError` callbacks from useQuery.
    // The logic is now handled imperatively in `handleAction` using async/await.
    const { refetch: fetchRequestById, isFetching: isFetchingRequest } = useQuery<SupplyRequest>({
        queryKey: ['supplyRequest_details', requestId],
        queryFn: () => workflowEngineApi.getRequestById(requestId.trim()),
        enabled: false,
    });

    const handleAction = async (action: string) => {
        switch (action) {
            case 'my_pending':
                navigate('/reports', { state: { filters: { assigneeId: String(currentUser!.id), status: 'IN_REVIEW' } } });
                setIsOpen(false);
                break;
            case 'my_rejected':
                navigate('/reports', { state: { filters: { requesterId: String(currentUser!.id), status: 'REJECTED' } } });
                setIsOpen(false);
                break;
            case 'request_status':
                if (requestId.trim()) {
                    try {
                        const { data } = await fetchRequestById();
                        if (data) {
                            setViewingRequest(data);
                            setIsOpen(false);
                        } else {
                            toast.error(`درخواست با شماره ${requestId} یافت نشد.`);
                        }
                    } catch (error) {
                        toast.error(`خطا در دریافت اطلاعات درخواست شماره ${requestId}.`);
                    }
                } else {
                    toast.error("لطفا شماره درخواست را وارد کنید.");
                }
                break;
            case 'search_by_date':
                if (dateFrom || dateTo) {
                    navigate('/reports', { state: { filters: { dateFrom, dateTo } } });
                    setIsOpen(false);
                } else {
                    toast.error("لطفا حداقل یک تاریخ برای جستجو وارد کنید.");
                }
                break;
            case 'manage_petty_cash':
                navigate('/petty-cash-management');
                setIsOpen(false);
                break;
            case 'search_by_type':
                if (selectedRequestTypeId) {
                    navigate('/reports', { state: { filters: { requestTypeId: selectedRequestTypeId } } });
                    setIsOpen(false);
                } else {
                    toast.error("لطفا یک نوع درخواست برای جستجو انتخاب کنید.");
                }
                break;
        }
    };
    
    if (!currentUser) return null;

    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className="no-print fixed bottom-6 left-6 z-50 bg-fuchsia-600 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg hover:bg-fuchsia-700 transition-transform transform hover:scale-110"
                aria-label="دستیار هوشمند"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
            </button>

            {isOpen && (
                <Modal title="دستیار هوشمند (آفلاین)" onClose={() => setIsOpen(false)} size="lg">
                    <div className="p-6 space-y-6">
                        <p className="text-sm text-gray-600">یک سوال از لیست زیر انتخاب کنید تا پاسخ آن نمایش داده شود:</p>
                        
                        <div className="space-y-4">
                            <button onClick={() => handleAction('my_pending')} className="w-full text-right p-3 bg-gray-100 hover:bg-fuchsia-100 rounded-lg font-semibold text-gray-800 transition">
                                کارهای منتظر اقدام من را نشان بده.
                            </button>

                             <button onClick={() => handleAction('my_rejected')} className="w-full text-right p-3 bg-gray-100 hover:bg-fuchsia-100 rounded-lg font-semibold text-gray-800 transition">
                                درخواست‌های رد شده من کدامند؟
                            </button>
                            
                            {canManagePettyCash && (
                                <button onClick={() => handleAction('manage_petty_cash')} className="w-full text-right p-3 bg-gray-100 hover:bg-fuchsia-100 rounded-lg font-semibold text-gray-800 transition">
                                    وضعیت همه تنخواه بگیران واحدها را در یک نگاه به من نشان بده.
                                </button>
                            )}

                            <div className="p-3 bg-gray-100 rounded-lg">
                                <label className="font-semibold text-gray-800 mb-2 block">آخرین وضعیت درخواست شماره ... را بگو.</label>
                                <div className="flex gap-2">
                                    <input 
                                        type="text" 
                                        value={requestId}
                                        onChange={(e) => setRequestId(e.target.value)}
                                        placeholder="مثال: SR-1725110000001" 
                                        className="w-full border p-2 rounded"
                                    />
                                    <button onClick={() => handleAction('request_status')} disabled={isFetchingRequest} className="bg-fuchsia-600 text-white px-4 py-2 rounded font-semibold disabled:bg-gray-400">
                                        {isFetchingRequest ? '...' : 'بررسی'}
                                    </button>
                                </div>
                            </div>

                            <div className="p-3 bg-gray-100 rounded-lg">
                                <label className="font-semibold text-gray-800 mb-2 block">جستجوی درخواست‌ها براساس بازه زمانی.</label>
                                <div className="flex gap-2 items-end">
                                    <div className="flex-1">
                                        <label className="text-xs">از تاریخ</label>
                                        <input 
                                            type="date" 
                                            value={dateFrom}
                                            onChange={(e) => setDateFrom(e.target.value)}
                                            className="w-full border p-2 rounded"
                                        />
                                    </div>
                                    <div className="flex-1">
                                        <label className="text-xs">تا تاریخ</label>
                                        <input 
                                            type="date" 
                                            value={dateTo}
                                            onChange={(e) => setDateTo(e.target.value)}
                                            className="w-full border p-2 rounded"
                                        />
                                    </div>
                                    <button onClick={() => handleAction('search_by_date')} className="bg-fuchsia-600 text-white px-4 py-2 rounded font-semibold">
                                        جستجو
                                    </button>
                                </div>
                            </div>

                            <div className="p-3 bg-gray-100 rounded-lg">
                                <label className="font-semibold text-gray-800 mb-2 block">جستجوی درخواست‌ها براساس نوع.</label>
                                <div className="flex gap-2">
                                    <select 
                                        value={selectedRequestTypeId}
                                        onChange={(e) => setSelectedRequestTypeId(e.target.value)}
                                        className="w-full border p-2 rounded bg-white"
                                    >
                                        <option value="">انتخاب نوع درخواست...</option>
                                        {(requestCategories || []).map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                                    </select>
                                    <button onClick={() => handleAction('search_by_type')} className="bg-fuchsia-600 text-white px-4 py-2 rounded font-semibold">
                                        جستجو
                                    </button>
                                </div>
                            </div>

                            <div className="p-3 bg-gray-100 rounded-lg">
                                <label className="font-semibold text-gray-800 mb-2 block">وضعیت فعلی حساب تنخواه ... را بهم بگو.</label>
                                <select 
                                    value={selectedPettyCashHolderId}
                                    onChange={(e) => setSelectedPettyCashHolderId(e.target.value)}
                                    className="w-full border p-2 rounded bg-white"
                                >
                                    <option value="">انتخاب تنخواه بگیر...</option>
                                    {pettyCashHolders.map(p => <option key={p.id} value={p.id}>{p.fullName}</option>)}
                                </select>
                                {selectedPettyCashHolder && (
                                    <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg text-sm">
                                        <p><strong>سقف اعتبار:</strong> {formatCurrency(selectedPettyCashHolder.pettyCashLimit, 'RIAL')}</p>
                                        <p><strong>موجودی باقیمانده:</strong> {formatCurrency(selectedPettyCashHolder.pettyCashBalance, 'RIAL')}</p>
                                    </div>
                                )}
                            </div>

                        </div>
                    </div>
                </Modal>
            )}
            
            {viewingRequest && (
// FIX: The RequestDetailsModal expects a `requestId` string prop, not a `request` object.
// Unnecessary data props have been removed as the modal fetches its own data.
                 <RequestDetailsModal
                    requestId={viewingRequest.id}
                    onClose={() => setViewingRequest(null)}
                    onActionComplete={() => {
                        setViewingRequest(null);
                        queryClient.invalidateQueries({ queryKey: ['dashboardRequests'] });
                        queryClient.invalidateQueries({ queryKey: ['reportList'] });
                    }}
                    loggedInUserId={currentUser.id}
                    isServerOffline={false}
                />
            )}
        </>
    );
};

export default OfflineAiAssistant;