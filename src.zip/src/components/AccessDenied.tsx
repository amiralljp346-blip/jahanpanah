
import React from 'react';

const AccessDenied: React.FC = () => (
  <div className="flex flex-col items-center justify-center h-full text-center bg-yellow-50 text-yellow-800 p-8 rounded-lg border border-yellow-200">
    <h2 className="text-2xl font-bold">دسترسی غیرمجاز</h2>
    <p className="mt-2">شما دسترسی لازم برای مشاهده این صفحه را ندارید.</p>
  </div>
);

export default AccessDenied;
