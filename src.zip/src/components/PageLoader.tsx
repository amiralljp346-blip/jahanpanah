
import React from 'react';

const PageLoader: React.FC = () => {
    return (
        <div className="flex h-full animate-pulse">
            {/* Fake Sidebar */}
            <div className="w-64 bg-gray-200 hidden lg:block" />
            <div className="flex-1 flex flex-col">
                {/* Fake Header */}
                <div className="h-[68px] bg-gray-200 flex-shrink-0" />
                {/* Fake Content */}
                <div className="p-8 space-y-6">
                    <div className="h-10 w-1/3 bg-gray-300 rounded-lg" />
                    <div className="h-48 bg-gray-300 rounded-lg" />
                     <div className="h-64 bg-gray-300 rounded-lg" />
                </div>
            </div>
        </div>
    );
};

export default PageLoader;
