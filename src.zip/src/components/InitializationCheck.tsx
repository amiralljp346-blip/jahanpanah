import React, { useState, useEffect } from 'react';

const InitializationCheck: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [isInitialized, setIsInitialized] = useState<boolean | null>(null);
    const [error, setError] = useState<string | null>(null);

    const checkDbStatus = async () => {
        setIsInitialized(null);
        setError(null);
        try {
            const response = await fetch(`/api/init-check?_=${new Date().getTime()}`, {
                method: 'GET',
                headers: { 'Cache-Control': 'no-cache', 'Pragma': 'no-cache' },
            });
            if (!response.ok) {
                const errBody = await response.json().catch(() => ({ message: `Server responded with status ${response.status}` }));
                throw new Error(errBody.message);
            }
            const data = await response.json();
            setIsInitialized(data.initialized);
            if (!data.initialized) {
                 setError("پایگاه داده راه‌اندازی نشده است.");
            }
        } catch (err: any) {
            console.error("Failed to check DB initialization status:", err);
            const serverMessage = err.message || "پاسخی از سرور دریافت نشد.";
            
            let userFriendlyError = "ارتباط با سرور پشتیبان برقرار نشد.";
            if (serverMessage.includes("does not exist")) {
                userFriendlyError = `خطا: پایگاه داده مشخص شده در فایل .env وجود ندارد. (پیام سرور: ${serverMessage})`;
            } else if (serverMessage.includes("ECONNREFUSED")) {
                userFriendlyError = `خطا در اتصال به پایگاه داده. آیا PostgreSQL در حال اجراست؟ (پیام سرور: ${serverMessage})`;
            } else if (serverMessage.includes("password authentication failed")) {
                userFriendlyError = `خطا: نام کاربری یا رمز عبور پایگاه داده در فایل .env اشتباه است. (پیام سرور: ${serverMessage})`;
            } else {
                userFriendlyError = `خطا در ارتباط با سرور پشتیبان: ${serverMessage}`;
            }
            
            setError(`${userFriendlyError} لطفا تنظیمات فایل .env را بررسی کرده و مطمئن شوید سرور (npm run dev:backend) در حال اجراست.`);
        }
    };

    useEffect(() => {
        checkDbStatus();
    }, []);


    if (isInitialized === null && !error) {
        return (
            <div className="flex flex-col justify-center items-center h-screen bg-gray-100 text-center">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-fuchsia-500"></div>
                <p className="mt-4 text-gray-700 font-semibold">در حال بررسی وضعیت پایگاه داده...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex flex-col justify-center items-center h-screen bg-red-50 text-red-800 p-8 text-center" dir="rtl">
                <h1 className="text-2xl font-bold mb-4">خطا در اتصال به سرور یا پایگاه داده</h1>
                <p className="max-w-2xl">{error}</p>
                 {isInitialized === false && (
                    <div className="mt-6 p-4 bg-yellow-100 text-yellow-900 rounded-lg max-w-2xl text-right">
                        <h3 className="font-bold">راهنما:</h3>
                        <ol className="list-decimal list-inside mt-2 space-y-1 text-sm">
                            <li>یک پایگاه داده خالی در pgAdmin بسازید.</li>
                            <li>محتوای فایل `Backend/setup.sql` را به طور کامل در Query Tool کپی و اجرا کنید.</li>
                            <li>پس از اجرای موفق اسکریپت، روی دکمه تلاش مجدد کلیک کنید.</li>
                        </ol>
                    </div>
                )}
                <button onClick={checkDbStatus} className="mt-6 bg-fuchsia-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-fuchsia-700">تلاش مجدد</button>
            </div>
        );
    }

    return <>{children}</>;
};

export default InitializationCheck;