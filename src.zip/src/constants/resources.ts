
export const PERMISSIONS = {
    READ: 'read',
    CREATE: 'create',
    UPDATE: 'update',
    DELETE: 'delete',
};

export const RESOURCES = {
    DASHBOARD: 'داشبورد',
    REPORTS: 'گزارش‌ها و جستجو',
    UNITS: 'ساختار سازمانی',
    PROJECTS: 'پروژه‌ها',
    PERSONS: 'تعریف اشخاص',
    BENEFICIARIES: 'مدیریت ذی‌نفعان',
    ROLES: 'نقش‌ها',
    WORKFLOW: 'خط فرایند',
    CONTRACTS: 'قراردادها',
    INTERNAL_WORKFLOWS: 'فرآیندهای داخلی',
    DEBIT: 'کارت بدهی',
    REQUEST_TYPES: 'انواع درخواست',
    PROFILE: 'پروفایل من',
    SECURITY: 'کاربران و امنیت',
    APPEARANCE: 'شخصی‌سازی ظاهر',
    PETTY_CASH_MANAGEMENT: 'مدیریت تنخواه',
    BACKUP: 'پشتیبان‌گیری',
    INVOICE_EXPLORER: 'کاوشگر اقلام فاکتور',
    AUDIT_LOG: 'گزارش رویدادها',
};

const createPermissions = (resourceName: string) => ({
    READ: `${resourceName}:read`,
    CREATE: `${resourceName}:create`,
    UPDATE: `${resourceName}:update`,
    DELETE: `${resourceName}:delete`,
});

type ResourceKey = keyof typeof RESOURCES;

export const PERMISSION_MAP: { [K in ResourceKey]: { [P in keyof typeof PERMISSIONS]?: string } & { [key: string]: string } } = {
    DASHBOARD: createPermissions('DASHBOARD'),
    REPORTS: createPermissions('REPORTS'),
    UNITS: createPermissions('UNITS'),
    PROJECTS: createPermissions('PROJECTS'),
    PERSONS: createPermissions('PERSONS'),
    BENEFICIARIES: createPermissions('BENEFICIARIES'),
    ROLES: createPermissions('ROLES'),
    WORKFLOW: createPermissions('WORKFLOW'),
    CONTRACTS: createPermissions('CONTRACTS'),
    INTERNAL_WORKFLOWS: createPermissions('INTERNAL_WORKFLOWS'),
    DEBIT: createPermissions('DEBIT'),
    REQUEST_TYPES: createPermissions('REQUEST_TYPES'),
    PROFILE: createPermissions('PROFILE'),
    SECURITY: createPermissions('SECURITY'),
    APPEARANCE: createPermissions('APPEARANCE'),
    BACKUP: createPermissions('BACKUP'),
    INVOICE_EXPLORER: createPermissions('INVOICE_EXPLORER'),
    AUDIT_LOG: createPermissions('AUDIT_LOG'),
    PETTY_CASH_MANAGEMENT: {
        read_own_unit: 'PETTY_CASH_MANAGEMENT:read_own_unit',
        read_all: 'PETTY_CASH_MANAGEMENT:read_all',
        update: 'PETTY_CASH_MANAGEMENT:update',
    },
};

export const ALL_PERMISSIONS_LIST = [
    ...Object.entries(RESOURCES)
        .filter(([key]) => !['PETTY_CASH_MANAGEMENT', 'BACKUP', 'INVOICE_EXPLORER', 'AUDIT_LOG', 'ROLES'].includes(key))
        .map(([resourceKey, resourceLabel]) => ({
            resourceKey,
            resourceLabel,
            permissions: [
                { key: 'READ', label: 'خواندن' },
                { key: 'CREATE', label: 'ایجاد' },
                { key: 'UPDATE', label: 'ویرایش' },
                { key: 'DELETE', label: 'حذف' },
            ]
        })),
    {
        resourceKey: 'ROLES',
        resourceLabel: 'نقش‌ها',
        permissions: [
            { key: 'READ', label: 'خواندن (بخشی از امنیت)' },
            { key: 'CREATE', label: 'ایجاد' },
            { key: 'UPDATE', label: 'ویرایش' },
            { key: 'DELETE', label: 'حذف' },
        ]
    },
    {
        resourceKey: 'INVOICE_EXPLORER',
        resourceLabel: 'کاوشگر اقلام فاکتور',
        permissions: [
            { key: 'READ', label: 'مشاهده' },
        ]
    },
     {
        resourceKey: 'AUDIT_LOG',
        resourceLabel: 'گزارش رویدادها',
        permissions: [
            { key: 'READ', label: 'مشاهده (بخشی از امنیت)' },
        ]
    },
    {
        resourceKey: 'BACKUP',
        resourceLabel: 'پشتیبان‌گیری',
        permissions: [
            { key: 'READ', label: 'مشاهده' },
            { key: 'CREATE', label: 'ایجاد پشتیبان' },
        ]
    },
    {
        resourceKey: 'PETTY_CASH_MANAGEMENT',
        resourceLabel: 'مدیریت تنخواه',
        permissions: [
            { key: 'read_own_unit', label: 'مشاهده تنخواه بگیران واحد خود' },
            { key: 'read_all', label: 'مشاهده همه تنخواه بگیران' },
            { key: 'update', label: 'تخصیص اعتبار و تایید گزارشات' },
        ]
    }
];