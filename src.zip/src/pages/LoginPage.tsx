
import React, { useState, useEffect } from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
// FIX: Replaced named imports from 'react-router-dom' with a namespace import to resolve module export errors.
import * as ReactRouterDOM from 'react-router-dom';
const { useNavigate, useLocation } = ReactRouterDOM;
// FIX: Replaced '@' alias with relative paths to resolve module errors.
import { useAuth } from '../hooks/useAuth';
import { authApi, appearanceApi } from '../services/api';
import { useMutation, useQuery } from '@tanstack/react-query';
import { AppearanceSettings, Person, AppearanceImage } from '../types';
import { useServerStatus } from '../context/ServerStatusContext';

type LoginFormValues = {
  username: string;
  password: string;
};

const LoginPage: React.FC = () => {
  const { register, handleSubmit, setError, formState: { errors } } = useForm<LoginFormValues>();
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as any)?.from?.pathname || '/dashboard';
  const { status: serverStatus } = useServerStatus();
  
  const [backgroundStyle, setBackgroundStyle] = useState<React.CSSProperties>({});

  const { data: settings } = useQuery<AppearanceSettings>({
      queryKey: ['appearanceSettings'],
      queryFn: appearanceApi.get,
      enabled: serverStatus === 'online',
  });

  useEffect(() => {
    if (!settings) return;

    const images = settings.images || [];

    const defaultStyle: React.CSSProperties = {
      backgroundImage: `
        url('data:image/svg+xml,<svg width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><g fill="none" stroke="%23FFFFFF" stroke-opacity="0.08" stroke-width="2"><circle cx="50" cy="50" r="10"/><ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(45 50 50)"/><ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(-45 50 50)"/><ellipse cx="50" cy="50" rx="40" ry="15" transform="rotate(90 50 50)"/></g></svg>'),
        linear-gradient(to top, #1e3c72 0%, #2a5298 100%)
      `
    };

    if (settings.mode === 'static' && settings.staticImageId) {
      const image = images.find((img: AppearanceImage) => img.id === settings.staticImageId);
      if (image) {
        setBackgroundStyle({ backgroundImage: `url(${image.url})` });
      } else {
        setBackgroundStyle(defaultStyle);
      }
    } else if (settings.mode === 'slideshow' && images.length > 0) {
      let currentIndex = 0;
      const updateBackground = () => {
        setBackgroundStyle({ 
          backgroundImage: `url(${images[currentIndex].url})`,
          transition: 'background-image 1s ease-in-out'
        });
        currentIndex = (currentIndex + 1) % images.length;
      };
      updateBackground();
      const intervalId = setInterval(updateBackground, 5000);
      return () => clearInterval(intervalId);
    } else {
      setBackgroundStyle(defaultStyle);
    }

  }, [settings]);

  const mutation = useMutation({
    mutationFn: (data: LoginFormValues) => authApi.login(data.username, data.password),
    onSuccess: (userWithPermissions: Person) => {
        login(userWithPermissions);
        navigate(from, { replace: true });
    },
    onError: (error: Error) => {
        setError("root.serverError", {
            type: "manual",
            message: error.message || 'نام کاربری یا رمز عبور اشتباه است.',
        });
    },
  });

  const onSubmit: SubmitHandler<LoginFormValues> = (data) => {
    mutation.mutate(data);
  };

  return (
    <div 
      className="flex items-center justify-center min-h-screen bg-cover bg-center transition-all duration-1000" 
      style={backgroundStyle}
    >
      <div className="w-full max-w-md p-8 space-y-6 bg-white bg-opacity-90 backdrop-blur-sm rounded-xl shadow-2xl">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-800">ورود به سامانه</h1>
          <p className="mt-2 text-sm text-gray-600">سامانه مدیریت زنجیره تامین</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <input type="hidden" name="remember" value="true" />
          <div className="rounded-md shadow-sm -space-y-px">
            <div>
              <label htmlFor="username" className="sr-only">نام کاربری</label>
              <input
                id="username"
                {...register("username", { required: "نام کاربری الزامی است" })}
                type="text"
                autoComplete="username"
                required
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-fuchsia-500 focus:border-fuchsia-500 focus:z-10 sm:text-sm"
                placeholder="نام کاربری"
              />
            </div>
            <div>
              <label htmlFor="password-input" className="sr-only">رمز عبور</label>
              <input
                id="password-input"
                {...register("password", { required: "رمز عبور الزامی است" })}
                type="password"
                autoComplete="current-password"
                required
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-fuchsia-500 focus:border-fuchsia-500 focus:z-10 sm:text-sm"
                placeholder="رمز عبور"
              />
            </div>
          </div>
          
          {errors.root?.serverError && (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded-md" role="alert">
                <p className="text-sm">{errors.root.serverError.message as string}</p>
              </div>
          )}

          <div>
            <button
              type="submit"
              disabled={mutation.isPending || serverStatus === 'offline'}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-fuchsia-600 hover:bg-fuchsia-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-fuchsia-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              <span className="absolute left-0 inset-y-0 flex items-center pl-3">
                {mutation.isPending ? (
                   <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                ) : (
                    <svg className="h-5 w-5 text-fuchsia-500 group-hover:text-fuchsia-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                    </svg>
                )}
              </span>
              {serverStatus === 'offline' ? 'سرور در دسترس نیست' : (mutation.isPending ? 'در حال ورود...' : 'ورود')}
            </button>
          </div>
        </form>
        <div className="text-xs text-center text-gray-500 mt-4">
            نسخه 1.0.0
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
