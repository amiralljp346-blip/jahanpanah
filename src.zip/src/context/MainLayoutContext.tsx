import React from 'react';
// FIX: Replaced '@' alias with a relative path to resolve module error.
import { Unit, Role, Person, RequestCategory, InternalWorkflow } from '../types';

// PERFORMANCE: The context no longer holds large datasets to improve initial load time.
// Components should fetch their own data as needed. These types are kept for
// potential future use with small, truly global data, but are currently unused.
export interface MainLayoutContextType {
  units: Unit[];
  roles: Role[];
  persons: Person[];
  requestCategories: RequestCategory[];
  internalWorkflows: InternalWorkflow[];
  isLoading: boolean;
}

export const MainLayoutContext = React.createContext<MainLayoutContextType | null>(null);

export const useMainLayoutContext = () => {
  const context = React.useContext(MainLayoutContext);
  if (!context) {
    throw new Error('useMainLayoutContext must be used inside a MainLayout component.');
  }
  return context;
};